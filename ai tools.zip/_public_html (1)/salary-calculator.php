<?php include 'header.php';?>

<?php
// Salary Calculation Function
function calculateSalary($basicSalary, $bonuses = 0, $deductions = 0) {
    // Calculate components (simplified for demo)
    $hra = $basicSalary * 0.4; // 40% of basic
    $specialAllowance = $basicSalary * 0.3; // 30% of basic
    $pf = min($basicSalary * 0.12, 1800); // 12% of basic (max 1800)
    
    $grossSalary = $basicSalary + $hra + $specialAllowance + $bonuses;
    $totalDeductions = $pf + $deductions;
    $netSalary = $grossSalary - $totalDeductions;
    
    return [
        'basic' => $basicSalary,
        'hra' => $hra,
        'special_allowance' => $specialAllowance,
        'bonuses' => $bonuses,
        'pf' => $pf,
        'other_deductions' => $deductions,
        'gross_salary' => $grossSalary,
        'total_deductions' => $totalDeductions,
        'net_salary' => $netSalary
    ];
}

// Handle form submission
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $basicSalary = (float)($_POST['basic_salary'] ?? 0);
    $bonuses = (float)($_POST['bonuses'] ?? 0);
    $deductions = (float)($_POST['deductions'] ?? 0);
    
    if ($basicSalary > 0) {
        $result = calculateSalary($basicSalary, $bonuses, $deductions);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Calculator - Calculate Your Take-Home Pay</title>
    <meta name="description" content="Free online salary calculator to estimate your take-home pay after taxes and deductions. Calculate HRA, PF, and other components.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .calculator-container {
            max-width: 800px;
            margin: 30px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .calculator-header {
            background: #6c5ce7;
            color: white;
            padding: 20px;
        }
        .calculator-body {
            padding: 25px;
        }
        .result-card {
            border-left: 4px solid #6c5ce7;
            background: #f8f9fa;
        }
        .component-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .highlight-result {
            font-size: 1.5rem;
            font-weight: bold;
            color: #6c5ce7;
        }
        @media (max-width: 576px) {
            .calculator-container {
                margin: 10px;
                border-radius: 0;
            }
        }
    </style>
</head>
<body>
    <div class="calculator-container">
        <div class="calculator-header">
            <h1 class="h3 mb-0">Salary Calculator</h1>
            <p class="mb-0">Calculate your take-home salary after deductions</p>
        </div>
        
        <div class="calculator-body">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="basic_salary" class="form-label">Basic Salary (₹)</label>
                        <input type="number" class="form-control" id="basic_salary" name="basic_salary" 
                               placeholder="e.g., 25000" required min="0" step="100">
                    </div>
                    <div class="col-md-6">
                        <label for="bonuses" class="form-label">Bonuses/Allowances (₹)</label>
                        <input type="number" class="form-control" id="bonuses" name="bonuses" 
                               placeholder="e.g., 2000" min="0" step="100" value="0">
                    </div>
                    <div class="col-md-6">
                        <label for="deductions" class="form-label">Other Deductions (₹)</label>
                        <input type="number" class="form-control" id="deductions" name="deductions" 
                               placeholder="e.g., 1500" min="0" step="100" value="0">
                    </div>
                    <div class="col-12 mt-3">
                        <button type="submit" class="btn btn-primary w-100 py-2">Calculate Salary</button>
                    </div>
                </div>
            </form>
            
            <?php if ($result): ?>
            <div class="mt-4 p-4 result-card">
                <h2 class="h4 mb-3">Salary Breakdown</h2>
                
                <div class="mb-4">
                    <div class="component-item">
                        <span>Basic Salary:</span>
                        <span>₹<?= number_format($result['basic'], 2) ?></span>
                    </div>
                    <div class="component-item">
                        <span>HRA (40% of Basic):</span>
                        <span>₹<?= number_format($result['hra'], 2) ?></span>
                    </div>
                    <div class="component-item">
                        <span>Special Allowance (30% of Basic):</span>
                        <span>₹<?= number_format($result['special_allowance'], 2) ?></span>
                    </div>
                    <div class="component-item">
                        <span>Bonuses/Allowances:</span>
                        <span>₹<?= number_format($result['bonuses'], 2) ?></span>
                    </div>
                    <div class="component-item">
                        <span>Provident Fund (PF):</span>
                        <span>₹<?= number_format($result['pf'], 2) ?></span>
                    </div>
                    <div class="component-item">
                        <span>Other Deductions:</span>
                        <span>₹<?= number_format($result['other_deductions'], 2) ?></span>
                    </div>
                </div>
                
                <div class="pt-3 border-top">
                    <div class="component-item">
                        <strong>Gross Salary:</strong>
                        <strong>₹<?= number_format($result['gross_salary'], 2) ?></strong>
                    </div>
                    <div class="component-item">
                        <strong>Total Deductions:</strong>
                        <strong>₹<?= number_format($result['total_deductions'], 2) ?></strong>
                    </div>
                    <div class="component-item">
                        <strong class="highlight-result">Net Take-Home Salary:</strong>
                        <strong class="highlight-result">₹<?= number_format($result['net_salary'], 2) ?></strong>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

<?php include 'footer.php';?>

</html>