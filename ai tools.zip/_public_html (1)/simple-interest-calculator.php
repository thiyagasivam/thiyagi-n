<?php include 'header.php';?>

<?php
// Function to calculate simple interest
function calculateSimpleInterest($principal, $rate, $time) {
    return ($principal * $rate * $time) / 100;
}

// Initialize variables
$principal = $rate = $time = $interest = $total = 0;
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $principal = filter_input(INPUT_POST, 'principal', FILTER_VALIDATE_FLOAT);
    $rate = filter_input(INPUT_POST, 'rate', FILTER_VALIDATE_FLOAT);
    $time = filter_input(INPUT_POST, 'time', FILTER_VALIDATE_FLOAT);
    
    if ($principal === false || $principal <= 0) {
        $error = 'Please enter a valid principal amount';
    } elseif ($rate === false || $rate <= 0) {
        $error = 'Please enter a valid interest rate';
    } elseif ($time === false || $time <= 0) {
        $error = 'Please enter a valid time period';
    } else {
        $interest = calculateSimpleInterest($principal, $rate, $time);
        $total = $principal + $interest;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Interest Calculator | Financial Tools</title>
    <meta name="description" content="Calculate simple interest on your investments or loans with our easy-to-use calculator.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #00d09c;
            --secondary-color: #f5f7fa;
            --text-color: #3c4e6d;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        
        .calculator-container {
            max-width: 600px;
            margin: 2rem auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        
        .calculator-header {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
        }
        
        .calculator-body {
            padding: 1.5rem;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(0, 208, 156, 0.25);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #00b388;
            border-color: #00b388;
        }
        
        .result-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 1.5rem;
            margin-top: 1.5rem;
        }
        
        .result-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .input-group-text {
            background-color: #e9ecef;
        }
        
        @media (max-width: 576px) {
            .calculator-container {
                margin: 1rem;
                border-radius: 8px;
            }
            
            .calculator-header h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="calculator-container">
        <div class="calculator-header text-center">
            <h2 class="mb-0">Simple Interest Calculator</h2>
        </div>
        
        <div class="calculator-body">
            <form method="POST">
                <div class="mb-3">
                    <label for="principal" class="form-label">Principal Amount (₹)</label>
                    <div class="input-group">
                        <span class="input-group-text">₹</span>
                        <input type="number" class="form-control" id="principal" name="principal" 
                               value="<?= htmlspecialchars($principal) ?>" step="0.01" min="1" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="rate" class="form-label">Annual Interest Rate (%)</label>
                    <div class="input-group">
                        <input type="number" class="form-control" id="rate" name="rate" 
                               value="<?= htmlspecialchars($rate) ?>" step="0.01" min="0.01" required>
                        <span class="input-group-text">%</span>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="time" class="form-label">Time Period (in years)</label>
                    <input type="number" class="form-control" id="time" name="time" 
                           value="<?= htmlspecialchars($time) ?>" step="0.1" min="0.1" required>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 py-2">Calculate</button>
            </form>
            
            <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)): ?>
                <div class="result-card">
                    <div class="row text-center">
                        <div class="col-md-6 mb-3">
                            <div>Principal Amount</div>
                            <div class="result-value">₹<?= number_format($principal, 2) ?></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div>Interest Rate</div>
                            <div class="result-value"><?= number_format($rate, 2) ?>%</div>
                        </div>
                    </div>
                    <div class="row text-center">
                        <div class="col-md-6 mb-3">
                            <div>Time Period</div>
                            <div class="result-value"><?= number_format($time, 1) ?> years</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div>Interest Amount</div>
                            <div class="result-value">₹<?= number_format($interest, 2) ?></div>
                        </div>
                    </div>
                    <hr>
                    <div class="text-center">
                        <div class="fs-5">Total Amount</div>
                        <div class="result-value fs-3">₹<?= number_format($total, 2) ?></div>
                    </div>
                </div>
            <?php elseif (!empty($error)): ?>
                <div class="alert alert-danger mt-3">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

<?php include 'footer.php';?>

</html>