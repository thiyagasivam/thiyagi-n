<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$month = isset($_GET['month']) ? $_GET['month'] : strtolower(date('F'));
$day = isset($_GET['day']) ? (int)$_GET['day'] : date('j');

$dateStr = "$year-$month-$day";
$date = date('Y-m-d', strtotime($dateStr));
$dayData = getDayData($date);

if (!$dayData) {
    header("HTTP/1.0 404 Not Found");
    include '../includes/404.php';
    exit;
}

$pageTitle = "தமிழ் காலண்டர் - " . date('j F Y', strtotime($date));
$metaDescription = $dayData['tamil_date'] . " தினத்தின் பஞ்சாங்கம் - நல்ல நேரம்: " . $dayData['good_times'] . ", ராகு காலம்: " . $dayData['rahu_kalam'];

include '../includes/header.php';
?>

<div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
    <div class="bg-tamil-blue text-white p-4">
        <h1 class="text-2xl font-bold"><?php echo $dayData['tamil_date']; ?></h1>
        <p class="text-tamil-gold"><?php echo date('l, j F Y', strtotime($date)); ?></p>
    </div>
    
    <div class="p-6">
        <?php if ($dayData['is_holiday']): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-red-700 font-bold"><?php echo htmlspecialchars($dayData['holiday_name']); ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <h2 class="text-xl font-semibold text-tamil-blue mb-3">நல்ல நேரம்</h2>
                <p class="text-gray-800"><?php echo nl2br(htmlspecialchars($dayData['good_times'])); ?></p>
                
                <h2 class="text-xl font-semibold text-tamil-blue mt-6 mb-3">கௌரி நல்ல நேரம்</h2>
                <p class="text-gray-800"><?php echo nl2br(htmlspecialchars($dayData['good_times'])); ?></p>
            </div>
            
            <div>
                <h2 class="text-xl font-semibold text-tamil-blue mb-3">தவிர்க்க வேண்டிய நேரம்</h2>
                <div class="space-y-4">
                    <div>
                        <h3 class="font-medium text-red-600">ராகு காலம்</h3>
                        <p><?php echo htmlspecialchars($dayData['rahu_kalam']); ?></p>
                    </div>
                    <div>
                        <h3 class="font-medium text-red-600">எமகண்டம்</h3>
                        <p><?php echo htmlspecialchars($dayData['yamagandam']); ?></p>
                    </div>
                    <div>
                        <h3 class="font-medium text-red-600">குளிகை நேரம்</h3>
                        <p><?php echo htmlspecialchars($dayData['gulikai']); ?></p>
                    </div>
                </div>
                
                <h2 class="text-xl font-semibold text-tamil-blue mt-6 mb-3">பரிகாரம்</h2>
                <p class="text-gray-800"><?php echo htmlspecialchars($dayData['remedy']); ?></p>
            </div>
        </div>
        
        <div class="mt-8 pt-6 border-t border-gray-200">
            <h2 class="text-xl font-semibold text-tamil-blue mb-3">மற்ற தகவல்கள்</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                    <h3 class="font-medium">திதி</h3>
                    <p><?php echo htmlspecialchars($dayData['tithi']); ?></p>
                </div>
                <div>
                    <h3 class="font-medium">நட்சத்திரம்</h3>
                    <p><?php echo htmlspecialchars($dayData['nakshatra']); ?></p>
                </div>
                <div>
                    <h3 class="font-medium">சூலம்</h3>
                    <p><?php echo htmlspecialchars($dayData['moon_phase']); ?></p>
                </div>
                <div>
                    <h3 class="font-medium">முகூர்த்தம்</h3>
                    <p><?php echo $dayData['is_muhurtham'] ? 'ஆம்' : 'இல்லை'; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mt-8 flex justify-between">
    <?php 
    $prevDay = date('Y-m-d', strtotime($date . ' -1 day'));
    $nextDay = date('Y-m-d', strtotime($date . ' +1 day'));
    ?>
    <a href="/calendar/<?php echo date('Y/m/d', strtotime($prevDay)); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
        <svg class="mr-2 h-5 w-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
        </svg>
        முந்தைய நாள்
    </a>
    <a href="/calendar/<?php echo date('Y/m/d', strtotime($nextDay)); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
        அடுத்த நாள்
        <svg class="ml-2 h-5 w-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
        </svg>
    </a>
</div>

<?php include '../includes/footer.php'; ?>