<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$month = isset($_GET['month']) ? $_GET['month'] : strtolower(date('F'));

// Convert month name to number
$monthNumber = date('m', strtotime("1 $month $year"));
$monthData = getMonthData($year, $monthNumber);

$pageTitle = "தமிழ் காலண்டர் - $month $year";
$metaDescription = "$month $year மாத தமிழ் காலண்டர் - நல்ல நேரம், ராகு காலம் மற்றும் பண்டிகைகள்";

include '../includes/header.php';
?>

<div class="max-w-6xl mx-auto">
    <h2 class="text-2xl font-bold text-center mb-6 text-tamil-blue"><?php echo ucfirst($month); ?> <?php echo $year; ?> மாத காலண்டர்</h2>
    
    <div class="grid grid-cols-1 md:grid-cols-7 gap-2 mb-6">
        <?php 
        $daysOfWeek = ['ஞாயிறு', 'திங்கள்', 'செவ்வாய்', 'புதன்', 'வியாழன்', 'வெள்ளி', 'சனி'];
        foreach ($daysOfWeek as $day): ?>
            <div class="text-center font-bold bg-tamil-blue text-white py-2 rounded"><?php echo $day; ?></div>
        <?php endforeach; ?>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-7 gap-2">
        <?php 
        // Get first day of month and its day of week (0=Sun, 6=Sat)
        $firstDay = date('w', strtotime("$year-$monthNumber-01"));
        
        // Add empty cells for days before the first day of month
        for ($i = 0; $i < $firstDay; $i++) {
            echo '<div class="h-24 bg-gray-100 rounded"></div>';
        }
        
        // Display days of month
        foreach ($monthData as $day) {
            $dayOfMonth = date('j', strtotime($day['gregorian_date']));
            $isToday = date('Y-m-d') == $day['gregorian_date'];
            
            echo '<div class="h-24 border rounded p-2 overflow-y-auto ' . ($isToday ? 'bg-tamil-gold bg-opacity-20 border-tamil-gold' : 'bg-white') . '">';
            echo '<div class="font-bold ' . ($isToday ? 'text-tamil-gold' : '') . '">' . $dayOfMonth . '</div>';
            echo '<div class="text-sm">' . $day['tamil_date'] . '</div>';
            
            if ($day['is_holiday']) {
                echo '<div class="text-xs mt-1 text-red-600 font-semibold">' . htmlspecialchars($day['holiday_name']) . '</div>';
            }
            
            echo '</div>';
        }
        ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>