<?php
function getMonthData($year, $month) {
    global $pdo;
    
    $start_date = "$year-$month-01";
    $end_date = date("Y-m-t", strtotime($start_date));
    
    $stmt = $pdo->prepare("SELECT * FROM calendar_days 
                          WHERE gregorian_date BETWEEN :start_date AND :end_date 
                          ORDER BY gregorian_date");
    $stmt->execute(['start_date' => $start_date, 'end_date' => $end_date]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getDayData($date) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM calendar_days WHERE gregorian_date = :date");
    $stmt->execute(['date' => $date]);
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function seoUrl($string) {
    $string = strtolower($string);
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    $string = preg_replace("/[\s-]+/", " ", $string);
    $string = preg_replace("/[\s_]/", "-", $string);
    return $string;
}

function tamilMonthToEnglish($tamilMonth) {
    $months = [
        'சித்திரை' => 'chithirai',
        'வைகாசி' => 'vaikasi',
        'ஆனி' => 'aani',
        'ஆடி' => 'aadi',
        'ஆவணி' => 'aavani',
        'புரட்டாசி' => 'purattasi',
        'ஐப்பசி' => 'aipassi',
        'கார்த்திகை' => 'karthikai',
        'மார்கழி' => 'margazhi',
        'தை' => 'thai',
        'மாசி' => 'maasi',
        'பங்குனி' => 'panguni'
    ];
    
    return $months[$tamilMonth] ?? strtolower($tamilMonth);
}
?>