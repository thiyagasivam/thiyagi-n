<?php include 'header.php'; ?>

<?php
// Handle form submission
$input = '';
$output = '';
$action = 'encode';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = $_POST['input'] ?? '';
    $action = $_POST['action'] ?? 'encode';
    
    try {
        if ($action === 'encode') {
            $output = urlencode($input);
        } elseif ($action === 'decode') {
            $output = urldecode($input);
        }
    } catch (Exception $e) {
        $error = 'An error occurred during processing.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL Encode/Decoder Tool</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        /* Additional custom styles */
        .tab-active {
            background-color: #3b82f6;
            color: white;
        }
        .tab-inactive {
            background-color: #e5e7eb;
            color: #4b5563;
        }
        .tab-inactive:hover {
            background-color: #d1d5db;
        }
        textarea {
            min-height: 150px;
        }
        .copy-btn {
            transition: all 0.2s;
        }
        .copy-btn:hover {
            transform: translateY(-1px);
        }
        .copy-btn:active {
            transform: translateY(1px);
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <header class="mb-8 text-center">
            <h1 class="text-3xl font-bold text-gray-800 mb-2">URL Encode/Decoder</h1>
            <p class="text-gray-600">Encode or decode URLs with this free online tool</p>
        </header>

        <main class="bg-white rounded-lg shadow-md overflow-hidden">
            <form method="POST" class="p-6">
                <div class="flex mb-4 rounded-md overflow-hidden">
                    <button type="submit" name="action" value="encode" 
                            class="<?= $action === 'encode' ? 'tab-active' : 'tab-inactive' ?> flex-1 py-2 px-4 font-medium">
                        Encode
                    </button>
                    <button type="submit" name="action" value="decode" 
                            class="<?= $action === 'decode' ? 'tab-active' : 'tab-inactive' ?> flex-1 py-2 px-4 font-medium">
                        Decode
                    </button>
                </div>

                <div class="mb-4">
                    <label for="input" class="block text-gray-700 font-medium mb-2">
                        <?= $action === 'encode' ? 'Text to encode' : 'URL to decode' ?>
                    </label>
                    <textarea name="input" id="input" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" 
                              rows="5" placeholder="<?= $action === 'encode' ? 'Enter text to encode as URL...' : 'Enter URL to decode...' ?>" required><?= htmlspecialchars($input) ?></textarea>
                </div>

                <button type="submit" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-4 rounded-md transition duration-200">
                    <?= $action === 'encode' ? 'Encode URL' : 'Decode URL' ?>
                </button>
            </form>

            <?php if (!empty($output) || !empty($error)): ?>
            <div class="border-t border-gray-200 p-6 bg-gray-50">
                <div class="flex justify-between items-center mb-2">
                    <h2 class="text-xl font-semibold text-gray-800">Result</h2>
                    <?php if (!empty($output)): ?>
                    <button onclick="copyToClipboard()" class="copy-btn bg-gray-200 hover:bg-gray-300 text-gray-800 py-1 px-3 rounded-md text-sm font-medium">
                        Copy to Clipboard
                    </button>
                    <?php endif; ?>
                </div>

                <?php if (!empty($error)): ?>
                    <div class="text-red-500"><?= htmlspecialchars($error) ?></div>
                <?php else: ?>
                    <div id="output" class="bg-white p-4 rounded-md border border-gray-200 whitespace-pre-wrap break-all"><?= htmlspecialchars($output) ?></div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </main>

        <section class="mt-8 bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">About URL Encoding/Decoding</h2>
            <div class="prose text-gray-700">
                <p>URL encoding converts characters into a format that can be transmitted over the Internet. URLs can only be sent over the Internet using the ASCII character-set.</p>
                <p class="mt-2">URL encoding replaces unsafe ASCII characters with a "%" followed by two hexadecimal digits corresponding to the character values in the ISO-8859-1 character-set.</p>
                <p class="mt-2">URL decoding is the reverse process, converting encoded characters back to their original form.</p>
            </div>
        </section>
    </div>

    <script>
        function copyToClipboard() {
            const output = document.getElementById('output');
            const range = document.createRange();
            range.selectNode(output);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            document.execCommand('copy');
            window.getSelection().removeAllRanges();
            
            const btn = document.querySelector('.copy-btn');
            btn.textContent = 'Copied!';
            setTimeout(() => {
                btn.textContent = 'Copy to Clipboard';
            }, 2000);
        }
    </script>
</body>
   <?php include 'footer.php'; ?>

</html>