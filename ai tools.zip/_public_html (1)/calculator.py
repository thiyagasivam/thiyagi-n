import tkinter as tk

# Function to update the expression in the entry field
def press(num):
    entry_var.set(entry_var.get() + str(num))

# Function to evaluate the expression
def equal_press():
    try:
        result = str(eval(entry_var.get()))
        entry_var.set(result)
    except:
        entry_var.set("Error")

# Function to clear the input field
def clear():
    entry_var.set("")

# Creating the main window
root = tk.Tk()
root.title("Simple Calculator")
root.geometry("300x400")

entry_var = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_var, font=("Arial", 18), justify='right', bd=10)
entry.grid(row=0, column=0, columnspan=4, ipadx=10, ipady=10)

# Button Layout
buttons = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
    ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
]

for (text, row, col) in buttons:
    action = lambda x=text: press(x) if x != "=" else equal_press()
    tk.Button(root, text=text, font=("Arial", 14), command=action, width=5, height=2).grid(row=row, column=col)

# Clear Button
tk.Button(root, text="C", font=("Arial", 14), command=clear, width=22, height=2).grid(row=5, column=0, columnspan=4)

root.mainloop()
