<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Text Tools</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        .tool-box {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            background: #fff;
            transition: 0.3s;
        }
        .tool-box:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .tool-icon {
            font-size: 30px;
            color: #007bff;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h2 class="text-center mb-4">Text Tools</h2>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3">
            <div class="col"><div class="tool-box"><i class="fas fa-pen tool-icon"></i> Article Rewriter</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-sort tool-icon"></i> Text Sorter</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-hashtag tool-icon"></i> Text to Hashtags</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-calculator tool-icon"></i> Word Counter</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-random tool-icon"></i> Random Word Generator</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-quote-left tool-icon"></i> Lorem Ipsum Generator</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-exchange-alt tool-icon"></i> Text Repeater</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-code tool-icon"></i> Text to Slug Converter</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-sort-alpha-up tool-icon"></i> Case Converter</div></div>
            <div class="col"><div class="tool-box"><i class="fas fa-sort-numeric-up tool-icon"></i> Number to Word Converter</div></div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
