<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Text Tools - Online Text Manipulation Utilities</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a6bff;
            --secondary-color: #6c8aff;
            --dark-color: #1a1a2e;
            --light-color: #f8f9fa;
            --accent-color: #ff6b6b;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: var(--dark-color);
        }
        
        .navbar {
            background-color: white;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }
        
        .navbar-brand {
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .hero-section {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 4rem 0;
            border-radius: 0 0 20px 20px;
            margin-bottom: 3rem;
        }
        
        .hero-title {
            font-weight: 800;
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .hero-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 2rem;
        }
        
        .btn-light {
            background-color: white;
            color: var(--primary-color);
            padding: 0.6rem 1.8rem;
            font-weight: 600;
            border: none;
        }
        
        .btn-light:hover {
            background-color: rgba(255, 255, 255, 0.9);
            color: var(--primary-color);
        }
        
        .btn-outline-light {
            border: 2px solid white;
            color: white;
            font-weight: 600;
        }
        
        .btn-outline-light:hover {
            background-color: white;
            color: var(--primary-color);
        }
        
        .section-title {
            font-weight: 700;
            margin-bottom: 2rem;
            position: relative;
            color: var(--dark-color);
        }
        
        .section-title:after {
            content: '';
            position: absolute;
            width: 60px;
            height: 4px;
            background: var(--accent-color);
            bottom: -10px;
            left: 0;
            border-radius: 2px;
        }
        
        .tool-card {
            background-color: white;
            border: none;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            height: 100%;
            padding: 1.5rem;
            position: relative;
            overflow: hidden;
        }
        
        .tool-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .tool-card:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: var(--primary-color);
        }
        
        .tool-icon {
            font-size: 1.8rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        .tool-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .tool-desc {
            font-size: 0.9rem;
            opacity: 0.8;
            margin-bottom: 1rem;
        }
        
        .category-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid rgba(74, 107, 255, 0.2);
        }
        
        .tool-link {
            display: block;
            padding: 0.5rem 0;
            color: var(--dark-color);
            text-decoration: none;
            transition: all 0.2s;
            border-radius: 5px;
            padding-left: 10px;
        }
        
        .tool-link:hover {
            background-color: rgba(74, 107, 255, 0.1);
            color: var(--primary-color);
            transform: translateX(5px);
        }
        
        .tool-link i {
            margin-right: 8px;
            color: var(--primary-color);
            width: 20px;
            text-align: center;
        }
        
        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 3rem 0 1.5rem;
            margin-top: 4rem;
        }
        
        .footer-links h5 {
            margin-bottom: 1.5rem;
            font-weight: 600;
        }
        
        .footer-links ul {
            list-style: none;
            padding-left: 0;
        }
        
        .footer-links li {
            margin-bottom: 0.7rem;
        }
        
        .footer-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: white;
        }
        
        .social-icons a {
            color: white;
            font-size: 1.2rem;
            margin-right: 1rem;
            transition: color 0.3s;
        }
        
        .social-icons a:hover {
            color: var(--accent-color);
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .hero-subtitle {
                font-size: 1rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .tool-card {
                padding: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-keyboard me-2"></i>
                Text Tools
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">All Tools</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">API</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Blog</a>
                    </li>
                </ul>
                <div class="ms-lg-3 mt-3 mt-lg-0">
                    <a href="#" class="btn btn-outline-primary me-2">Login</a>
                    <a href="#" class="btn btn-primary">Sign Up</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="hero-title">Powerful Text Manipulation Tools</h1>
                    <p class="hero-subtitle">Transform, analyze, and optimize your text with our free online tools. Perfect for writers, developers, and marketers.</p>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="#tools" class="btn btn-light">Explore Tools</a>
                        <a href="#" class="btn btn-outline-light">How It Works</a>
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block">
                    <img src="https://cdn-icons-png.flaticon.com/512/2933/2933245.png" alt="Text Tools Illustration" class="img-fluid" style="max-height: 300px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Tools Section -->
    <section class="py-5" id="tools">
        <div class="container">
            <h2 class="section-title">Text Tools Categories</h2>
            <p class="mb-5">Browse our collection of free online text manipulation utilities</p>
            
            <div class="row g-4">
                <!-- Rewriter Tools -->
                <div class="col-lg-3 col-md-6">
                    <div class="tool-card">
                        <h4 class="category-title"><i class="fas fa-pen-fancy me-2"></i>Article Rewriter</h4>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Word Counter</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Backwards Text Generator</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Text to Hashtags Converter</a>
                    </div>
                </div>
                
                <!-- Compare Tools -->
                <div class="col-lg-3 col-md-6">
                    <div class="tool-card">
                        <h4 class="category-title"><i class="fas fa-code-compare me-2"></i>Text Compare</h4>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Text to Slug Converter</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Lorem Ipsum Generator</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Case Converter</a>
                    </div>
                </div>
                
                <!-- Formatting Tools -->
                <div class="col-lg-3 col-md-6">
                    <div class="tool-card">
                        <h4 class="category-title"><i class="fas fa-align-left me-2"></i>Remove Line Breaks</h4>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Random Word Generator</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Text Repeater</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Text Sorter</a>
                    </div>
                </div>
                
                <!-- Conversion Tools -->
                <div class="col-lg-3 col-md-6">
                    <div class="tool-card">
                        <h4 class="category-title"><i class="fas fa-exchange-alt me-2"></i>Comma Separator</h4>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Number to Word Converter</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Word to Number Converter</a>
                        <a href="#" class="tool-link"><i class="fas fa-arrow-right"></i> Text to Tags Converter</a>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-5">
                <a href="#" class="btn btn-primary px-4">View All Text Tools</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5 bg-white">
        <div class="container">
            <h2 class="text-center section-title">Why Use Our Text Tools</h2>
            <p class="text-center mb-5">We provide the most comprehensive collection of text manipulation utilities</p>
            
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="tool-card text-center">
                        <div class="tool-icon mx-auto">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <h4 class="tool-title">Instant Results</h4>
                        <p class="tool-desc">Get immediate transformations without any delays or processing time.</p>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="tool-card text-center">
                        <div class="tool-icon mx-auto">
                            <i class="fas fa-lock"></i>
                        </div>
                        <h4 class="tool-title">Privacy Focused</h4>
                        <p class="tool-desc">All processing happens in your browser - we never store your text.</p>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="tool-card text-center">
                        <div class="tool-icon mx-auto">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <h4 class="tool-title">Mobile Friendly</h4>
                        <p class="tool-desc">Use our tools on any device, anywhere, without any compromise.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 my-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="mb-4">Ready to Transform Your Text?</h2>
                    <p class="lead mb-4">Join thousands of writers, developers, and marketers who use our tools daily.</p>
                    <a href="#tools" class="btn btn-primary btn-lg px-4 me-2">Start Using Now</a>
                    <a href="#" class="btn btn-outline-primary btn-lg px-4">Learn More</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h5 class="mb-3"><i class="fas fa-keyboard me-2"></i> Text Tools</h5>
                    <p>Free online utilities for all your text manipulation needs. No registration required.</p>
                    <div class="social-icons mt-3">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <div class="footer-links">
                        <h5>Tools</h5>
                        <ul>
                            <li><a href="#">All Tools</a></li>
                            <li><a href="#">New Tools</a></li>
                            <li><a href="#">Popular</a></li>
                            <li><a href="#">API Access</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <div class="footer-links">
                        <h5>Resources</h5>
                        <ul>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Tutorials</a></li>
                            <li><a href="#">Cheat Sheets</a></li>
                            <li><a href="#">Help</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <div class="footer-links">
                        <h5>Company</h5>
                        <ul>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Contact</a></li>
                            <li><a href="#">Privacy</a></li>
                            <li><a href="#">Terms</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4">
                    <div class="footer-links">
                        <h5>Support</h5>
                        <ul>
                            <li><a href="#">Help Center</a></li>
                            <li><a href="#">Feedback</a></li>
                            <li><a href="#">Report Bug</a></li>
                            <li><a href="#">Feature Request</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <hr class="mt-4 mb-3" style="border-color: rgba(255,255,255,0.1);">
            
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">© 2023 Text Tools. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0">Made with <i class="fas fa-heart text-danger"></i> for text enthusiasts</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarNav = document.querySelector('#navbarNav');
            
            navbarToggler.addEventListener('click', function() {
                navbarNav.classList.toggle('show');
            });
            
            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    if (targetId === '#') return;
                    
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 80,
                            behavior: 'smooth'
                        });
                        
                        // Close mobile menu if open
                        if (navbarNav.classList.contains('show')) {
                            navbarNav.classList.remove('show');
                        }
                    }
                });
            });
            
            // Add shadow to navbar on scroll
            window.addEventListener('scroll', function() {
                const navbar = document.querySelector('.navbar');
                if (window.scrollY > 10) {
                    navbar.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.1)';
                } else {
                    navbar.style.boxShadow = '0 2px 15px rgba(0, 0, 0, 0.1)';
                }
            });
            
            // Add animation to tool cards when they come into view
            const observerOptions = {
                threshold: 0.1
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = 1;
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);
            
            document.querySelectorAll('.tool-card').forEach(card => {
                card.style.opacity = 0;
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                observer.observe(card);
            });
        });
    </script>
</body>
</html>