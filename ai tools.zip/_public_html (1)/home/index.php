<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEO Studio Tools - Free SEO Tools for Digital Marketers</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4f46e5;
            --secondary-color: #6366f1;
            --dark-color: #1e293b;
            --light-color: #f8fafc;
            --success-color: #10b981;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .navbar-brand {
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .hero-section {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            padding: 5rem 0;
            border-radius: 0 0 20px 20px;
        }
        
        .hero-title {
            font-weight: 800;
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .hero-subtitle {
            font-size: 1.2rem;
            opacity: 0.8;
            margin-bottom: 2rem;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            padding: 0.5rem 1.5rem;
            font-weight: 600;
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .tool-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 100%;
        }
        
        .tool-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .tool-icon {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        .section-title {
            font-weight: 700;
            margin-bottom: 2rem;
            position: relative;
            display: inline-block;
        }
        
        .section-title:after {
            content: '';
            position: absolute;
            width: 50%;
            height: 4px;
            background: var(--primary-color);
            bottom: -10px;
            left: 0;
            border-radius: 2px;
        }
        
        .feature-icon {
            width: 50px;
            height: 50px;
            background: rgba(79, 70, 229, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            color: var(--primary-color);
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 3rem 0;
        }
        
        .footer-links h5 {
            margin-bottom: 1.5rem;
            font-weight: 600;
        }
        
        .footer-links ul {
            list-style: none;
            padding-left: 0;
        }
        
        .footer-links li {
            margin-bottom: 0.5rem;
        }
        
        .footer-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: white;
        }
        
        .social-icons a {
            color: white;
            font-size: 1.2rem;
            margin-right: 1rem;
            transition: color 0.3s;
        }
        
        .social-icons a:hover {
            color: var(--secondary-color);
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .hero-subtitle {
                font-size: 1rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-chart-line me-2"></i>
                SEO Studio Tools
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Tools</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Blog</a>
                    </li>
                </ul>
                <div class="ms-lg-3 mt-3 mt-lg-0">
                    <a href="#" class="btn btn-outline-primary me-2">Login</a>
                    <a href="#" class="btn btn-primary">Sign Up</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="hero-title">Powerful SEO Tools to Grow Your Website</h1>
                    <p class="hero-subtitle">Analyze, optimize and track your website's performance with our comprehensive suite of free SEO tools.</p>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="#" class="btn btn-primary">Get Started for Free</a>
                        <a href="#" class="btn btn-outline-dark">Explore Tools</a>
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block">
                    <img src="https://seostudio.tools/assets/images/hero-illustration.svg" alt="SEO Tools Illustration" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- Tools Section -->
    <section class="py-5 my-5">
        <div class="container">
            <h2 class="text-center section-title">Popular SEO Tools</h2>
            <p class="text-center mb-5">Our most used tools to help you improve your website's search engine rankings</p>
            
            <div class="row g-4">
                <!-- Tool Card 1 -->
                <div class="col-md-4 col-sm-6">
                    <div class="card tool-card p-4">
                        <div class="tool-icon">
                            <i class="fas fa-search"></i>
                        </div>
                        <h4>Keyword Research</h4>
                        <p>Find the best keywords to target for your content and marketing campaigns.</p>
                        <a href="#" class="btn btn-sm btn-outline-primary mt-auto align-self-start">Use Tool</a>
                    </div>
                </div>
                
                <!-- Tool Card 2 -->
                <div class="col-md-4 col-sm-6">
                    <div class="card tool-card p-4">
                        <div class="tool-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <h4>Rank Tracker</h4>
                        <p>Monitor your keyword rankings across search engines and locations.</p>
                        <a href="#" class="btn btn-sm btn-outline-primary mt-auto align-self-start">Use Tool</a>
                    </div>
                </div>
                
                <!-- Tool Card 3 -->
                <div class="col-md-4 col-sm-6">
                    <div class="card tool-card p-4">
                        <div class="tool-icon">
                            <i class="fas fa-link"></i>
                        </div>
                        <h4>Backlink Checker</h4>
                        <p>Analyze your backlink profile and discover linking opportunities.</p>
                        <a href="#" class="btn btn-sm btn-outline-primary mt-auto align-self-start">Use Tool</a>
                    </div>
                </div>
                
                <!-- Tool Card 4 -->
                <div class="col-md-4 col-sm-6">
                    <div class="card tool-card p-4">
                        <div class="tool-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <h4>Content Analyzer</h4>
                        <p>Optimize your content for better search engine visibility.</p>
                        <a href="#" class="btn btn-sm btn-outline-primary mt-auto align-self-start">Use Tool</a>
                    </div>
                </div>
                
                <!-- Tool Card 5 -->
                <div class="col-md-4 col-sm-6">
                    <div class="card tool-card p-4">
                        <div class="tool-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        <h4>Site Audit</h4>
                        <p>Identify technical SEO issues affecting your website's performance.</p>
                        <a href="#" class="btn btn-sm btn-outline-primary mt-auto align-self-start">Use Tool</a>
                    </div>
                </div>
                
                <!-- Tool Card 6 -->
                <div class="col-md-4 col-sm-6">
                    <div class="card tool-card p-4">
                        <div class="tool-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h4>Competitor Analysis</h4>
                        <p>Research your competitors' SEO strategies and outperform them.</p>
                        <a href="#" class="btn btn-sm btn-outline-primary mt-auto align-self-start">Use Tool</a>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-5">
                <a href="#" class="btn btn-outline-primary">View All Tools</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center section-title">Why Choose Our SEO Tools</h2>
            <p class="text-center mb-5">We provide the most comprehensive and accurate SEO analysis tools</p>
            
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="feature-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h4>Fast & Accurate</h4>
                    <p>Our tools deliver instant results with industry-leading accuracy to help you make data-driven decisions.</p>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <div class="feature-icon">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <h4>Privacy Focused</h4>
                    <p>We don't store or sell your data. All analyses are performed securely in your browser.</p>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <div class="feature-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h4>Powerful Features</h4>
                    <p>Access advanced SEO metrics and insights typically only available in premium tools.</p>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h4>Mobile Friendly</h4>
                    <p>All our tools work perfectly on any device, so you can do SEO analysis anywhere.</p>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <div class="feature-icon">
                        <i class="fas fa-sync-alt"></i>
                    </div>
                    <h4>Regular Updates</h4>
                    <p>We continuously improve our tools to keep up with the latest SEO trends and algorithms.</p>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <div class="feature-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <h4>Community Support</h4>
                    <p>Join our active community to get help and share SEO knowledge with other marketers.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 my-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="mb-4">Ready to Boost Your SEO?</h2>
                    <p class="lead mb-4">Join thousands of marketers and website owners who use our tools to improve their search rankings.</p>
                    <a href="#" class="btn btn-primary btn-lg px-4">Start Using Tools Now</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h5 class="mb-3"><i class="fas fa-chart-line me-2"></i> SEO Studio Tools</h5>
                    <p>Free SEO tools to help you analyze, optimize and improve your website's search engine performance.</p>
                    <div class="social-icons mt-3">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-github"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <div class="footer-links">
                        <h5>Tools</h5>
                        <ul>
                            <li><a href="#">Keyword Research</a></li>
                            <li><a href="#">Rank Tracker</a></li>
                            <li><a href="#">Backlink Checker</a></li>
                            <li><a href="#">Site Audit</a></li>
                            <li><a href="#">Content Analyzer</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <div class="footer-links">
                        <h5>Resources</h5>
                        <ul>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Guides</a></li>
                            <li><a href="#">Tutorials</a></li>
                            <li><a href="#">API</a></li>
                            <li><a href="#">Help Center</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <div class="footer-links">
                        <h5>Company</h5>
                        <ul>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Pricing</a></li>
                            <li><a href="#">Careers</a></li>
                            <li><a href="#">Contact</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-4">
                    <div class="footer-links">
                        <h5>Support</h5>
                        <ul>
                            <li><a href="#">Help Desk</a></li>
                            <li><a href="#">Community</a></li>
                            <li><a href="#">Feedback</a></li>
                            <li><a href="#">Status</a></li>
                            <li><a href="#">Report Bug</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <hr class="mt-4 mb-3" style="border-color: rgba(255,255,255,0.1);">
            
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">© 2023 SEO Studio Tools. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0">Made with <i class="fas fa-heart text-danger"></i> for SEO professionals</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarNav = document.querySelector('#navbarNav');
            
            navbarToggler.addEventListener('click', function() {
                navbarNav.classList.toggle('show');
            });
            
            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    if (targetId === '#') return;
                    
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 70,
                            behavior: 'smooth'
                        });
                        
                        // Close mobile menu if open
                        if (navbarNav.classList.contains('show')) {
                            navbarNav.classList.remove('show');
                        }
                    }
                });
            });
            
            // Add shadow to navbar on scroll
            window.addEventListener('scroll', function() {
                const navbar = document.querySelector('.navbar');
                if (window.scrollY > 10) {
                    navbar.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
                } else {
                    navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
                }
            });
        });
    </script>
</body>
</html>