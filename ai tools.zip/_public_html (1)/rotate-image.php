<?php include 'header.php';?>

<?php
// Handle image upload and rotation
$error = '';
$processedImage = '';
$rotationAngle = 90; // Default rotation angle

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if file was uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['image'];
        $rotationAngle = isset($_POST['angle']) ? (int)$_POST['angle'] : 90;
        
        // Validate image
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($fileInfo, $file['tmp_name']);
        
        if (!in_array($mimeType, $allowedTypes)) {
            $error = 'Only JPG, PNG, and GIF images are allowed.';
        } else {
            // Create image resource based on type
            switch ($mimeType) {
                case 'image/jpeg':
                    $image = imagecreatefromjpeg($file['tmp_name']);
                    break;
                case 'image/png':
                    $image = imagecreatefrompng($file['tmp_name']);
                    break;
                case 'image/gif':
                    $image = imagecreatefromgif($file['tmp_name']);
                    break;
            }
            
            if ($image) {
                // Rotate image
                $rotatedImage = imagerotate($image, $rotationAngle, 0);
                
                // Save rotated image
                $outputFilename = 'rotated_' . time() . '_' . $file['name'];
                $outputPath = 'uploads/' . $outputFilename;
                
                // Create uploads directory if it doesn't exist
                if (!file_exists('uploads')) {
                    mkdir('uploads', 0755, true);
                }
                
                // Save based on original type
                switch ($mimeType) {
                    case 'image/jpeg':
                        imagejpeg($rotatedImage, $outputPath, 90);
                        break;
                    case 'image/png':
                        imagepng($rotatedImage, $outputPath, 9);
                        break;
                    case 'image/gif':
                        imagegif($rotatedImage, $outputPath);
                        break;
                }
                
                $processedImage = $outputPath;
                
                // Free memory
                imagedestroy($image);
                imagedestroy($rotatedImage);
            } else {
                $error = 'Failed to process the image.';
            }
        }
    } else {
        $error = 'Please select an image to upload.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Rotator Tool</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .dropzone {
            border: 2px dashed #cbd5e0;
            transition: all 0.3s ease;
        }
        .dropzone.active {
            border-color: #4299e1;
            background-color: #ebf8ff;
        }
        .rotate-btn {
            transition: all 0.2s ease;
        }
        .rotate-btn:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-3xl mx-auto">
            <h1 class="text-3xl font-bold text-center text-gray-800 mb-2">Image Rotator Tool</h1>
            <p class="text-center text-gray-600 mb-8">Upload an image and rotate it to any angle</p>
            
            <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                <form id="rotateForm" method="POST" enctype="multipart/form-data" class="space-y-6">
                    <div class="dropzone rounded-lg p-8 text-center cursor-pointer" id="dropzone">
                        <input type="file" name="image" id="image" class="hidden" accept="image/*">
                        <div class="flex flex-col items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            <p class="text-gray-600 mb-1">Drag & drop your image here or click to browse</p>
                            <p class="text-sm text-gray-400">Supports JPG, PNG, GIF (Max 5MB)</p>
                        </div>
                    </div>
                    
                    <div id="previewContainer" class="hidden">
                        <div class="flex justify-center mb-4">
                            <img id="imagePreview" class="max-h-64 rounded-lg shadow-sm" src="" alt="Preview">
                        </div>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div class="w-full sm:w-1/2">
                            <label for="angle" class="block text-sm font-medium text-gray-700 mb-1">Rotation Angle</label>
                            <div class="flex items-center gap-3">
                                <input type="range" name="angle" id="angle" min="0" max="360" value="90" step="90" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer">
                                <span id="angleValue" class="text-gray-700 font-medium w-12 text-center">90°</span>
                            </div>
                        </div>
                        
                        <button type="submit" class="w-full sm:w-auto rotate-btn bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all">
                            Rotate Image
                        </button>
                    </div>
                </form>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm text-red-700"><?php echo htmlspecialchars($error); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if ($processedImage): ?>
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">Your Rotated Image</h2>
                    <div class="flex flex-col items-center">
                        <img src="<?php echo htmlspecialchars($processedImage); ?>" alt="Rotated Image" class="max-h-96 rounded-lg shadow-sm mb-4">
                        <div class="flex flex-wrap gap-3 justify-center">
                            <a href="<?php echo htmlspecialchars($processedImage); ?>" download class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                Download Image
                            </a>
                            <button onclick="resetForm()" class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                Rotate Another Image
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Drag and drop functionality
        const dropzone = document.getElementById('dropzone');
        const fileInput = document.getElementById('image');
        const previewContainer = document.getElementById('previewContainer');
        const imagePreview = document.getElementById('imagePreview');
        const angleInput = document.getElementById('angle');
        const angleValue = document.getElementById('angleValue');
        
        // Update angle display
        angleInput.addEventListener('input', () => {
            angleValue.textContent = `${angleInput.value}°`;
        });
        
        // Handle dropzone click
        dropzone.addEventListener('click', () => {
            fileInput.click();
        });
        
        // Handle file selection
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length) {
                updatePreview(e.target.files[0]);
            }
        });
        
        // Handle drag over
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('active');
        });
        
        // Handle drag leave
        dropzone.addEventListener('dragleave', () => {
            dropzone.classList.remove('active');
        });
        
        // Handle drop
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('active');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                updatePreview(e.dataTransfer.files[0]);
            }
        });
        
        // Update preview
        function updatePreview(file) {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
                previewContainer.classList.remove('hidden');
                
                // Update dropzone text
                dropzone.innerHTML = `
                    <div class="flex flex-col items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-green-500 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <p class="text-gray-700 font-medium">${file.name}</p>
                        <p class="text-sm text-gray-500">${(file.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                `;
            };
            
            reader.readAsDataURL(file);
        }
        
        // Reset form
        function resetForm() {
            document.getElementById('rotateForm').reset();
            previewContainer.classList.add('hidden');
            angleValue.textContent = '90°';
            
            // Reset dropzone
            dropzone.innerHTML = `
                <div class="flex flex-col items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p class="text-gray-600 mb-1">Drag & drop your image here or click to browse</p>
                    <p class="text-sm text-gray-400">Supports JPG, PNG, GIF (Max 5MB)</p>
                </div>
            `;
            
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    </script>
</body>

<?php include 'footer.php';?>


</html>