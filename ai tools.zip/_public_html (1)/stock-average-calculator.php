<?php include 'header.php';?>

<?php
// Stock Average Calculator Logic
function calculateAverage($transactions) {
    $totalShares = 0;
    $totalCost = 0;
    
    foreach ($transactions as $transaction) {
        $totalShares += $transaction['shares'];
        $totalCost += $transaction['shares'] * $transaction['price'];
    }
    
    if ($totalShares > 0) {
        $averagePrice = $totalCost / $totalShares;
        return [
            'average_price' => round($averagePrice, 2),
            'total_shares' => $totalShares,
            'total_investment' => round($totalCost, 2)
        ];
    }
    
    return null;
}

// Handle form submission
$results = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $transactions = [];
    
    // Process each transaction
    for ($i = 1; $i <= 5; $i++) {
        if (!empty($_POST["shares_$i"]) && !empty($_POST["price_$i"])) {
            $transactions[] = [
                'shares' => (float)$_POST["shares_$i"],
                'price' => (float)$_POST["price_$i"]
            ];
        }
    }
    
    if (!empty($transactions)) {
        $results = calculateAverage($transactions);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Average Calculator | Groww Clone</title>
    <meta name="description" content="Calculate your average stock purchase price with our free stock average calculator. Perfect for investors using Groww or other platforms.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #00d09c;
            --secondary-color: #f5f5f5;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .calculator-container {
            max-width: 800px;
            margin: 2rem auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        
        .calculator-header {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
        }
        
        .transaction-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            align-items: center;
        }
        
        .result-card {
            background-color: var(--secondary-color);
            border-radius: 8px;
            padding: 1.5rem;
            margin-top: 1.5rem;
        }
        
        .result-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        @media (max-width: 768px) {
            .transaction-row {
                flex-direction: column;
                gap: 8px;
            }
            
            .transaction-row input {
                width: 100% !important;
            }
        }
    </style>
</head>
<body>
    <div class="calculator-container">
        <div class="calculator-header">
            <h1 class="h3 mb-0">Stock Average Calculator</h1>
            <p class="mb-0">Calculate your average purchase price for stocks</p>
        </div>
        
        <div class="p-4">
            <form method="POST">
                <h2 class="h5 mb-3">Enter Your Transactions</h2>
                
                <?php for ($i = 1; $i <= 5; $i++): ?>
                <div class="transaction-row">
                    <div class="flex-grow-1">
                        <label for="shares_<?= $i ?>" class="form-label">Quantity (Shares)</label>
                        <input type="number" step="0.01" class="form-control" id="shares_<?= $i ?>" name="shares_<?= $i ?>" placeholder="100">
                    </div>
                    <div class="flex-grow-1">
                        <label for="price_<?= $i ?>" class="form-label">Purchase Price (₹)</label>
                        <input type="number" step="0.01" class="form-control" id="price_<?= $i ?>" name="price_<?= $i ?>" placeholder="150.50">
                    </div>
                </div>
                <?php endfor; ?>
                
                <button type="submit" class="btn btn-primary btn-lg w-100 mt-3" style="background-color: var(--primary-color); border: none;">
                    Calculate Average Price
                </button>
            </form>
            
            <?php if ($results): ?>
            <div class="result-card">
                <h3 class="h5 mb-3">Your Average Stock Price</h3>
                <div class="row">
                    <div class="col-md-4 text-center mb-3">
                        <p class="mb-1">Average Price</p>
                        <p class="result-value">₹<?= number_format($results['average_price'], 2) ?></p>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <p class="mb-1">Total Shares</p>
                        <p class="result-value"><?= number_format($results['total_shares']) ?></p>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <p class="mb-1">Total Investment</p>
                        <p class="result-value">₹<?= number_format($results['total_investment'], 2) ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="mt-4 pt-3 border-top">
                <h3 class="h5">How to Use This Calculator</h3>
                <ol>
                    <li>Enter each stock purchase with quantity and price</li>
                    <li>Click "Calculate Average Price"</li>
                    <li>View your average purchase price and total investment</li>
                </ol>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

<?php include 'footer.php';?>

</html>