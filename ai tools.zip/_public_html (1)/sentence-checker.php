<?php include 'header.php';?>

<?php
// Function to analyze sentences
function analyzeSentence($text) {
    $results = [
        'characters' => mb_strlen($text),
        'words' => str_word_count($text),
        'sentences' => preg_match_all('/[^\s]([.!?])(?!\w)/', $text, $matches),
        'paragraphs' => substr_count($text, "\n") + 1,
        'reading_time' => ceil(str_word_count($text) / 200) // 200 wpm average
    ];
    
    // Grammar check simulation (in a real app, use API like LanguageTool)
    $grammarIssues = [];
    if (preg_match('/\b(their|there|they\'re)\b/i', $text, $matches)) {
        $grammarIssues[] = "Potential homophone issue: " . $matches[0];
    }
    if (!preg_match('/[.!?]$/', trim($text))) {
        $grammarIssues[] = "Sentence may be incomplete or missing punctuation";
    }
    
    $results['grammar_issues'] = $grammarIssues;
    return $results;
}

// Handle form submission
$results = null;
$inputText = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputText = $_POST['text'] ?? '';
    if (!empty($inputText)) {
        $results = analyzeSentence($inputText);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sentence Checker | Analyze and Improve Your Sentences</title>
    <meta name="description" content="Free online sentence checker tool that analyzes your text for grammar, readability, and structure. Perfect for writers, students, and professionals.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a6ee0;
            --secondary-color: #f8f9fa;
            --accent-color: #ff6b6b;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            line-height: 1.6;
        }
        
        .tool-container {
            max-width: 900px;
            margin: 2rem auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .tool-header {
            background: var(--primary-color);
            color: white;
            padding: 1.5rem;
            text-align: center;
        }
        
        .tool-header h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .tool-body {
            padding: 2rem;
        }
        
        textarea {
            min-height: 200px;
            resize: vertical;
        }
        
        .result-card {
            border-left: 4px solid var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .result-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .grammar-issue {
            color: var(--accent-color);
            position: relative;
            padding-left: 1.5rem;
        }
        
        .grammar-issue:before {
            content: "⚠";
            position: absolute;
            left: 0;
        }
        
        @media (max-width: 768px) {
            .tool-header h1 {
                font-size: 1.5rem;
            }
            
            .stat-number {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="tool-container">
        <div class="tool-header">
            <h1>Sentence Checker</h1>
            <p class="mb-0">Analyze and improve your sentences for better readability</p>
        </div>
        
        <div class="tool-body">
            <form method="POST">
                <div class="mb-3">
                    <label for="text" class="form-label">Enter your text to analyze:</label>
                    <textarea class="form-control" id="text" name="text" rows="8" required><?= htmlspecialchars($inputText) ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-lg w-100">Analyze Sentence</button>
            </form>
            
            <?php if ($results): ?>
                <div class="mt-5">
                    <h2 class="mb-4">Analysis Results</h2>
                    
                    <div class="row g-4">
                        <div class="col-md-3">
                            <div class="card result-card h-100">
                                <div class="card-body text-center">
                                    <div class="stat-number"><?= $results['characters'] ?></div>
                                    <div class="card-text">Characters</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="card result-card h-100">
                                <div class="card-body text-center">
                                    <div class="stat-number"><?= $results['words'] ?></div>
                                    <div class="card-text">Words</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="card result-card h-100">
                                <div class="card-body text-center">
                                    <div class="stat-number"><?= $results['sentences'] ?></div>
                                    <div class="card-text">Sentences</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="card result-card h-100">
                                <div class="card-body text-center">
                                    <div class="stat-number"><?= $results['reading_time'] ?></div>
                                    <div class="card-text">Min. Reading Time</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($results['grammar_issues'])): ?>
                        <div class="mt-4 card border-warning">
                            <div class="card-header bg-warning text-white">
                                Potential Grammar Issues
                            </div>
                            <div class="card-body">
                                <ul class="mb-0">
                                    <?php foreach ($results['grammar_issues'] as $issue): ?>
                                        <li class="grammar-issue"><?= htmlspecialchars($issue) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mt-4 alert alert-success">
                            No obvious grammar issues found. Great job!
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

<?php include 'footer.php';?>


</html>