<?php include 'header.php';?>

<?php
// Handle image upload and flipping
$error = '';
$processedImage = '';
$originalImage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    // Check for upload errors
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $error = 'File upload error: ' . $_FILES['image']['error'];
    } else {
        // Validate file type
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileType = mime_content_type($_FILES['image']['tmp_name']);
        
        if (!in_array($fileType, $allowedTypes)) {
            $error = 'Only JPG, PNG, and GIF images are allowed.';
        } else {
            // Process the image
            try {
                $originalImage = 'uploads/original_' . basename($_FILES['image']['name']);
                move_uploaded_file($_FILES['image']['tmp_name'], $originalImage);
                
                // Determine flip type
                $flipType = $_POST['flip_type'] ?? 'horizontal';
                
                // Create image resource based on type
                switch ($fileType) {
                    case 'image/jpeg':
                        $image = imagecreatefromjpeg($originalImage);
                        break;
                    case 'image/png':
                        $image = imagecreatefrompng($originalImage);
                        break;
                    case 'image/gif':
                        $image = imagecreatefromgif($originalImage);
                        break;
                }
                
                // Flip the image
                $flipped = imagecreatetruecolor(imagesx($image), imagesy($image));
                
                if ($flipType === 'horizontal') {
                    imagecopyresampled($flipped, $image, 0, 0, (imagesx($image) - 1), 0, imagesx($image), imagesy($image), -imagesx($image), imagesy($image));
                } else {
                    imagecopyresampled($flipped, $image, 0, 0, 0, (imagesy($image) - 1), imagesx($image), imagesy($image), imagesx($image), -imagesy($image));
                }
                
                // Save the flipped image
                $processedImage = 'uploads/flipped_' . basename($_FILES['image']['name']);
                
                switch ($fileType) {
                    case 'image/jpeg':
                        imagejpeg($flipped, $processedImage, 90);
                        break;
                    case 'image/png':
                        imagepng($flipped, $processedImage, 9);
                        break;
                    case 'image/gif':
                        imagegif($flipped, $processedImage);
                        break;
                }
                
                // Clean up
                imagedestroy($image);
                imagedestroy($flipped);
                
            } catch (Exception $e) {
                $error = 'Error processing image: ' . $e->getMessage();
            }
        }
    }
}

// Clean up old files (optional)
array_map('unlink', glob("uploads/*"));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Flip Tool - Flip Images Horizontally or Vertically</title>
    <meta name="description" content="Free online tool to flip images horizontally or vertically. No registration required.">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .dropzone {
            border: 2px dashed #cbd5e0;
            transition: all 0.3s ease;
        }
        .dropzone.active {
            border-color: #4299e1;
            background-color: #ebf8ff;
        }
        .image-preview {
            max-height: 300px;
            object-fit: contain;
        }
        .flip-btn {
            transition: all 0.2s ease;
        }
        .flip-btn:hover {
            transform: scale(1.05);
        }
        @media (max-width: 640px) {
            .flex-col-mobile {
                flex-direction: column;
            }
            .w-full-mobile {
                width: 100% !important;
            }
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <header class="text-center mb-8">
            <h1 class="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Image Flip Tool</h1>
            <p class="text-gray-600">Flip your images horizontally or vertically in seconds</p>
        </header>

        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <form id="flipForm" method="POST" enctype="multipart/form-data" class="space-y-4">
                <div>
                    <label class="block text-gray-700 font-medium mb-2" for="image">Select Image</label>
                    <div id="dropzone" class="dropzone rounded-lg p-8 text-center cursor-pointer">
                        <input type="file" name="image" id="image" accept="image/*" class="hidden" required>
                        <div class="flex flex-col items-center justify-center">
                            <svg class="w-12 h-12 text-gray-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                            <p class="text-gray-600 mb-1">Drag & drop your image here or click to browse</p>
                            <p class="text-sm text-gray-500">Supports JPG, PNG, GIF (Max 5MB)</p>
                        </div>
                    </div>
                </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-2">Flip Direction</label>
                    <div class="flex flex-col-mobile space-y-2 md:space-y-0 md:space-x-4">
                        <label class="inline-flex items-center">
                            <input type="radio" name="flip_type" value="horizontal" checked class="h-4 w-4 text-blue-600">
                            <span class="ml-2 text-gray-700">Horizontal Flip (Mirror)</span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" name="flip_type" value="vertical" class="h-4 w-4 text-blue-600">
                            <span class="ml-2 text-gray-700">Vertical Flip (Upside Down)</span>
                        </label>
                    </div>
                </div>

                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200 flip-btn">
                    Flip Image Now
                </button>
            </form>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-8 rounded">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>

        <?php if ($processedImage && file_exists($processedImage)): ?>
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Your Flipped Image</h2>
                <div class="flex flex-col md:flex-row gap-6">
                    <div class="flex-1">
                        <h3 class="text-gray-700 font-medium mb-2">Original</h3>
                        <img src="<?php echo htmlspecialchars($originalImage); ?>" alt="Original image" class="image-preview w-full border rounded">
                    </div>
                    <div class="flex-1">
                        <h3 class="text-gray-700 font-medium mb-2">Flipped</h3>
                        <img src="<?php echo htmlspecialchars($processedImage); ?>" alt="Flipped image" class="image-preview w-full border rounded">
                    </div>
                </div>
                <div class="mt-6 flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo htmlspecialchars($processedImage); ?>" download class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded text-center transition duration-200 flip-btn">
                        Download Flipped Image
                    </a>
                    <button onclick="window.location.reload()" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded transition duration-200 flip-btn">
                        Flip Another Image
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!--<footer class="text-center py-6 text-gray-500 text-sm">-->
    <!--    <p>Free online image flip tool - No registration required</p>-->
    <!--</footer>-->

    <script>
        // Drag and drop functionality
        const dropzone = document.getElementById('dropzone');
        const fileInput = document.getElementById('image');

        dropzone.addEventListener('click', () => fileInput.click());
        
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            dropzone.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, unhighlight, false);
        });

        function highlight() {
            dropzone.classList.add('active');
        }

        function unhighlight() {
            dropzone.classList.remove('active');
        }

        dropzone.addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            if (files.length) {
                fileInput.files = files;
                updateFileDisplay(files[0]);
            }
        }

        fileInput.addEventListener('change', function() {
            if (this.files.length) {
                updateFileDisplay(this.files[0]);
            }
        });

        function updateFileDisplay(file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                dropzone.innerHTML = `
                    <div class="flex items-center justify-center">
                        <img src="${e.target.result}" alt="Preview" class="max-h-32 max-w-full rounded">
                    </div>
                    <p class="text-sm text-gray-600 mt-2">${file.name}</p>
                `;
            };
            reader.readAsDataURL(file);
        }
    </script>
</body>

<?php include 'footer.php';?>

</html>