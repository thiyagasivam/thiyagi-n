<?php include 'header.php';?>
<?php
// Function to generate YouTube embed code
function generateEmbedCode($videoUrl) {
    // Extract video ID from URL
    parse_str(parse_url($videoUrl, PHP_URL_QUERY), $params);
    $videoId = $params['v'] ?? '';

    if (!empty($videoId)) {
        $embedCode = '<iframe width="560" height="315" src="https://www.youtube.com/embed/' . htmlspecialchars($videoId) . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
        return $embedCode;
    } else {
        return '';
    }
}

// Handle form submission
$embedCode = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $videoUrl = $_POST['video_url'];
    if (!empty($videoUrl)) {
        $embedCode = generateEmbedCode($videoUrl);
        if (empty($embedCode)) {
            $error = 'Invalid YouTube video URL. Please check the URL and try again.';
        }
    } else {
        $error = 'Please enter a YouTube video URL.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Embed Code Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold text-center mb-6">YouTube Embed Code Generator</h1>
        <form method="POST" class="bg-white p-6 rounded-lg shadow-md">
            <div class="mb-4">
                <label for="video_url" class="block text-gray-700 font-bold mb-2">Enter YouTube Video URL:</label>
                <input type="url" name="video_url" id="video_url" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., https://www.youtube.com/watch?v=VIDEO_ID" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300">Generate Embed Code</button>
        </form>
        <?php if (!empty($embedCode)): ?>
            <div class="mt-6 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-2xl font-bold text-gray-800">Generated Embed Code:</h2>
                <div class="mt-4 p-4 bg-gray-100 rounded-lg">
                    <pre class="text-gray-700 text-sm overflow-x-auto"><?php echo htmlspecialchars($embedCode); ?></pre>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mt-6">Preview:</h3>
                <div class="mt-4">
                    <?php echo $embedCode; ?>
                </div>
            </div>
        <?php elseif (!empty($error)): ?>
            <div class="mt-6 bg-red-100 p-6 rounded-lg shadow-md">
                <p class="text-red-700 text-xl"><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>
<?php include 'footer.php';?>

</html>