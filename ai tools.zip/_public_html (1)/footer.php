<?php include 'page_sharing.php';?>


<footer class="footer">
    <div class="container">
        <div class="row">
            <!-- Company Info and Logo -->
            <div class="col-lg-3 col-md-6 footer-col">
                <img src="./seo-tools.png" alt="SEO Studio Logo" class="footer-logo">
                <p class="footer-about">
                    SEO Studio provides free online tools to help marketers, developers, and content creators 
                    optimize their websites and digital content.
                </p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <!-- Tools Categories -->
            <div class="col-lg-3 col-md-6 footer-col">
                <h5>SEO Tools</h5>
                <ul class="footer-links">
                    <li><a href="keyword-research.php">Keyword Research</a></li>
                    <li><a href="backlink-checker.php">Backlink Checker</a></li>
                    <li><a href="website-analyzer.php">Website Analyzer</a></li>
                    <li><a href="meta-tag-generator.php">Meta Tag Generator</a></li>
                    <li><a href="sitemap-generator.php">Sitemap Generator</a></li>
                    <li><a href="robots-txt-generator.php">Robots.txt Generator</a></li>
                </ul>
            </div>

            <!-- More Tools -->
            <div class="col-lg-3 col-md-6 footer-col">
                <h5>Content Tools</h5>
                <ul class="footer-links">
                    <li><a href="plagiarism-checker.php">Plagiarism Checker</a></li>
                    <li><a href="grammar-checker.php">Grammar Checker</a></li>
                    <li><a href="word-counter.php">Word Counter</a></li>
                    <li><a href="text-repeater.php">Text Repeater</a></li>
                    <li><a href="case-converter.php">Case Converter</a></li>
                    <li><a href="html-encoder.php">HTML Encoder</a></li>
                </ul>
            </div>

            <!-- Newsletter -->
            <div class="col-lg-3 col-md-6 footer-col">
                <h5>Newsletter</h5>
                <p class="footer-about">Subscribe to get updates on new tools and features.</p>
                <form class="newsletter-form">
                    <div class="input-group mb-3">
                        <input type="email" class="form-control" placeholder="Your Email" required>
                        <button class="btn btn-primary" type="submit">Subscribe</button>
                    </div>
                </form>
                
                <h5 class="mt-4">Quick Links</h5>
                <ul class="footer-links">
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="privacy.php">Privacy Policy</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>

        <!-- Copyright -->
        <div class="row">
            <div class="col-md-12 text-center copyright">
                <p>Copyrights &copy; <script>document.write(new Date().getFullYear())</script> All Rights Reserved by SEOStudio</p>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="scripts.js"></script>
</body>
</html>