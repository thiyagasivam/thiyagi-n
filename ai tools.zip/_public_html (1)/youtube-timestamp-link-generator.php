<?php include 'header.php';?>

<?php
// Function to generate YouTube timestamp links
function generateTimestampLink($videoUrl, $timestamp) {
    // Extract video ID from URL
    parse_str(parse_url($videoUrl, PHP_URL_QUERY), $params);
    $videoId = $params['v'] ?? '';

    if (empty($videoId)) {
        return 'Invalid YouTube video URL.';
    }

    // Validate timestamp format (HH:MM:SS or MM:SS)
    if (!preg_match('/^\d{1,2}:\d{2}(:\d{2})?$/', $timestamp)) {
        return 'Invalid timestamp format. Use HH:MM:SS or MM:SS.';
    }

    // Convert timestamp to seconds
    $parts = array_reverse(explode(':', $timestamp));
    $seconds = 0;
    foreach ($parts as $index => $part) {
        $seconds += intval($part) * pow(60, $index);
    }

    // Generate timestamp link
    return "https://www.youtube.com/watch?v=$videoId&t=$seconds";
}

// Handle form submission
$timestampLink = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $videoUrl = $_POST['video_url'];
    $timestamp = $_POST['timestamp'];

    if (!empty($videoUrl) && !empty($timestamp)) {
        $timestampLink = generateTimestampLink($videoUrl, $timestamp);
        if (strpos($timestampLink, 'http') !== 0) {
            $error = $timestampLink; // If the function returns an error message
            $timestampLink = '';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Timestamp Link Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold text-center mb-6">YouTube Timestamp Link Generator</h1>
        <form method="POST" class="bg-white p-6 rounded-lg shadow-md">
            <div class="mb-4">
                <label for="video_url" class="block text-gray-700 font-bold mb-2">YouTube Video URL:</label>
                <input type="url" name="video_url" id="video_url" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., https://www.youtube.com/watch?v=VIDEO_ID" required>
            </div>
            <div class="mb-4">
                <label for="timestamp" class="block text-gray-700 font-bold mb-2">Timestamp (HH:MM:SS or MM:SS):</label>
                <input type="text" name="timestamp" id="timestamp" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., 1:30 or 01:30:00" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300">Generate Link</button>
        </form>
        <?php if (!empty($timestampLink)): ?>
            <div class="mt-6 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-2xl font-bold text-gray-800">Generated Timestamp Link:</h2>
                <a href="<?php echo htmlspecialchars($timestampLink); ?>" target="_blank" class="text-blue-500 text-xl mt-2 break-all"><?php echo htmlspecialchars($timestampLink); ?></a>
            </div>
        <?php elseif (!empty($error)): ?>
            <div class="mt-6 bg-red-100 p-6 rounded-lg shadow-md">
                <p class="text-red-700 text-xl"><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>
<?php include 'footer.php';?>

</html>