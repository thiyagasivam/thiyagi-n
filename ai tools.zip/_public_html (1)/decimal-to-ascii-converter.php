<?php include 'header.php';?>

<?php
// Function to convert decimal to ASCII
function decimalToAscii($input) {
    $output = '';
    $decimals = preg_split('/[\s,]+/', trim($input));
    
    foreach ($decimals as $decimal) {
        if (is_numeric($decimal)) {
            $asciiChar = chr((int)$decimal);
            // Replace non-printable characters with a placeholder
            $output .= ctype_print($asciiChar) ? $asciiChar : '�';
        }
    }
    
    return $output;
}

// Handle form submission
$result = '';
$input = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = $_POST['decimal_input'] ?? '';
    $result = decimalToAscii($input);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Decimal to ASCII Converter | Online Tool</title>
    <meta name="description" content="Free online tool to convert decimal numbers to ASCII characters. Simple, fast, and accurate conversion.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .tool-container {
            max-width: 800px;
            margin: 30px auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 30px;
        }
        .tool-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .tool-header h1 {
            color: #2c3e50;
            font-weight: 700;
        }
        .tool-header p {
            color: #7f8c8d;
        }
        .input-area {
            margin-bottom: 20px;
        }
        .result-area {
            margin-top: 30px;
        }
        .btn-convert {
            background-color: #3498db;
            border: none;
            padding: 10px 20px;
            font-weight: 600;
        }
        .btn-convert:hover {
            background-color: #2980b9;
        }
        .form-control {
            min-height: 150px;
        }
        .result-box {
            background-color: #f1f8fe;
            border: 1px solid #d6e9ff;
            border-radius: 5px;
            padding: 15px;
            min-height: 100px;
        }
        .copy-btn {
            background-color: #2ecc71;
            border: none;
            margin-top: 10px;
        }
        .copy-btn:hover {
            background-color: #27ae60;
        }
        .feature-list {
            margin-top: 40px;
        }
        .feature-card {
            padding: 20px;
            border-radius: 8px;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        .feature-card h3 {
            color: #3498db;
            font-size: 1.2rem;
        }
        @media (max-width: 768px) {
            .tool-container {
                margin: 15px auto;
                padding: 20px;
            }
            .tool-header h1 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container tool-container">
        <div class="tool-header">
            <h1>Decimal to ASCII Converter</h1>
            <p>Convert decimal numbers to ASCII characters instantly</p>
        </div>

        <form method="POST">
            <div class="input-area">
                <label for="decimal_input" class="form-label">Enter Decimal Numbers:</label>
                <textarea class="form-control" id="decimal_input" name="decimal_input" rows="5" placeholder="Enter decimal numbers separated by spaces or commas (e.g., 72 101 108 108 111)"><?= htmlspecialchars($input) ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-convert">Convert to ASCII</button>
        </form>

        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <div class="result-area">
            <h3>Result:</h3>
            <div class="result-box">
                <?= htmlspecialchars($result) ?>
            </div>
            <button class="btn btn-success copy-btn" onclick="copyToClipboard()">Copy Result</button>
        </div>
        <?php endif; ?>

        <div class="feature-list">
            <h2 class="text-center mb-4">About This Tool</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="feature-card">
                        <h3>What is Decimal to ASCII?</h3>
                        <p>Decimal to ASCII conversion translates numeric decimal values to their corresponding ASCII characters. Each ASCII character is represented by a unique decimal number between 0 and 127.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-card">
                        <h3>How to Use</h3>
                        <p>Enter decimal numbers separated by spaces or commas. Our tool will convert each number to its ASCII character equivalent and display the complete string.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyToClipboard() {
            const resultText = document.querySelector('.result-box').innerText;
            navigator.clipboard.writeText(resultText).then(() => {
                alert('Copied to clipboard!');
            });
        }
    </script>
</body>

<?php include 'footer.php';?>

</html>