<?php include 'header.php';?>

<?php
// Function to calculate the views-to-engagement ratio
function calculateRatio($views, $engagement) {
    if ($views > 0 && $engagement > 0) {
        return number_format(($engagement / $views) * 100, 2) . '%';
    }
    return 'N/A';
}

// Handle form submission
$ratio = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $views = isset($_POST['views']) ? (int)$_POST['views'] : 0;
    $engagement = isset($_POST['engagement']) ? (int)$_POST['engagement'] : 0;

    if ($views > 0 && $engagement > 0) {
        $ratio = calculateRatio($views, $engagement);
    } else {
        $error = 'Please enter valid numbers for views and engagement.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Views Ratio Calculator</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold text-center mb-6">YouTube Views Ratio Calculator</h1>
        <form method="POST" class="bg-white p-6 rounded-lg shadow-md">
            <div class="mb-4">
                <label for="views" class="block text-gray-700 font-bold mb-2">Total Views:</label>
                <input type="number" name="views" id="views" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., 10000" required>
            </div>
            <div class="mb-4">
                <label for="engagement" class="block text-gray-700 font-bold mb-2">Total Engagement (Likes + Comments):</label>
                <input type="number" name="engagement" id="engagement" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., 500" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300">Calculate Ratio</button>
        </form>
        <?php if (!empty($ratio)): ?>
            <div class="mt-6 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-2xl font-bold text-gray-800">Views-to-Engagement Ratio:</h2>
                <p class="text-gray-700 text-xl mt-2"><?php echo htmlspecialchars($ratio); ?></p>
            </div>
        <?php elseif (!empty($error)): ?>
            <div class="mt-6 bg-red-100 p-6 rounded-lg shadow-md">
                <p class="text-red-700 text-xl"><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>

<?php include 'footer.php';?>


</html>