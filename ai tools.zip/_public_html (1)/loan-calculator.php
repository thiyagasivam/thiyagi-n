<?php include 'header.php';?>

<?php
// Loan calculation function
function calculateLoan($principal, $interestRate, $termYears, $termMonths) {
    $totalMonths = ($termYears * 12) + $termMonths;
    $monthlyRate = ($interestRate / 100) / 12;
    
    if ($monthlyRate == 0) {
        $monthlyPayment = $principal / $totalMonths;
    } else {
        $monthlyPayment = $principal * $monthlyRate * pow(1 + $monthlyRate, $totalMonths) / (pow(1 + $monthlyRate, $totalMonths) - 1);
    }
    
    $totalPayment = $monthlyPayment * $totalMonths;
    $totalInterest = $totalPayment - $principal;
    
    return [
        'monthly_payment' => $monthlyPayment,
        'total_payment' => $totalPayment,
        'total_interest' => $totalInterest,
        'term_months' => $totalMonths
    ];
}

// Handle form submission
$results = null;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $principal = filter_input(INPUT_POST, 'principal', FILTER_VALIDATE_FLOAT);
    $interestRate = filter_input(INPUT_POST, 'interest_rate', FILTER_VALIDATE_FLOAT);
    $termYears = filter_input(INPUT_POST, 'term_years', FILTER_VALIDATE_INT);
    $termMonths = filter_input(INPUT_POST, 'term_months', FILTER_VALIDATE_INT);
    
    // Validate inputs
    if ($principal === false || $principal <= 0) {
        $errors[] = "Please enter a valid loan amount";
    }
    if ($interestRate === false || $interestRate < 0) {
        $errors[] = "Please enter a valid interest rate";
    }
    if (($termYears === false || $termYears < 0) && ($termMonths === false || $termMonths < 0)) {
        $errors[] = "Please enter a valid loan term";
    }
    
    if (empty($errors)) {
        $termYears = max(0, $termYears ?? 0);
        $termMonths = max(0, $termMonths ?? 0);
        
        if ($termYears == 0 && $termMonths == 0) {
            $errors[] = "Loan term cannot be zero";
        } else {
            $results = calculateLoan($principal, $interestRate, $termYears, $termMonths);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Calculator | Calculate Your Monthly Payments</title>
    <meta name="description" content="Free online loan calculator to estimate monthly payments, total interest, and amortization schedule for your personal, auto, or mortgage loans.">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        /* Custom styles */
        .input-group {
            @apply mb-4;
        }
        .input-label {
            @apply block text-gray-700 text-sm font-bold mb-2;
        }
        .input-field {
            @apply shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline;
        }
        .btn-primary {
            @apply bg-blue-500 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg w-full transition duration-200;
        }
        .result-card {
            @apply bg-white p-6 rounded-lg shadow-md mt-6;
        }
        .result-title {
            @apply text-2xl font-bold text-gray-800 mb-4;
        }
        .result-value {
            @apply text-3xl font-bold text-blue-600;
        }
        .error-message {
            @apply text-red-500 text-sm italic;
        }
        .tabs {
            @apply flex mb-6 border-b border-gray-200;
        }
        .tab {
            @apply py-2 px-4 font-medium text-gray-500 hover:text-blue-500 cursor-pointer;
        }
        .tab-active {
            @apply text-blue-600 border-b-2 border-blue-600;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4 max-w-3xl">
        <h1 class="text-3xl font-bold text-center mb-2 text-gray-800">Loan Calculator</h1>
        <p class="text-center text-gray-600 mb-8">Calculate your monthly payments, total interest, and more</p>
        
        <div class="bg-white rounded-lg shadow-md p-6">
            <form method="POST">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="input-group">
                        <label for="principal" class="input-label">Loan Amount ($)</label>
                        <input type="number" id="principal" name="principal" class="input-field" 
                               placeholder="10,000" step="100" min="0" 
                               value="<?= isset($_POST['principal']) ? htmlspecialchars($_POST['principal']) : '' ?>" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="interest_rate" class="input-label">Interest Rate (%)</label>
                        <input type="number" id="interest_rate" name="interest_rate" class="input-field" 
                               placeholder="5.5" step="0.01" min="0" max="100" 
                               value="<?= isset($_POST['interest_rate']) ? htmlspecialchars($_POST['interest_rate']) : '' ?>" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="term_years" class="input-label">Loan Term (Years)</label>
                        <input type="number" id="term_years" name="term_years" class="input-field" 
                               placeholder="5" min="0" 
                               value="<?= isset($_POST['term_years']) ? htmlspecialchars($_POST['term_years']) : '5' ?>">
                    </div>
                    
                    <div class="input-group">
                        <label for="term_months" class="input-label">Loan Term (Months)</label>
                        <input type="number" id="term_months" name="term_months" class="input-field" 
                               placeholder="6" min="0" max="11" 
                               value="<?= isset($_POST['term_months']) ? htmlspecialchars($_POST['term_months']) : '0' ?>">
                    </div>
                </div>
                
                <?php if (!empty($errors)): ?>
                    <div class="mt-4">
                        <?php foreach ($errors as $error): ?>
                            <p class="error-message"><?= htmlspecialchars($error) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <div class="mt-6">
                    <button type="submit" class="btn-primary">Calculate Loan</button>
                </div>
            </form>
        </div>
        
        <?php if ($results): ?>
            <div class="result-card">
                <h2 class="result-title">Loan Summary</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div class="text-center p-4 bg-gray-50 rounded-lg">
                        <div class="text-gray-600 mb-1">Monthly Payment</div>
                        <div class="result-value">$<?= number_format($results['monthly_payment'], 2) ?></div>
                    </div>
                    
                    <div class="text-center p-4 bg-gray-50 rounded-lg">
                        <div class="text-gray-600 mb-1">Total Interest</div>
                        <div class="result-value">$<?= number_format($results['total_interest'], 2) ?></div>
                    </div>
                    
                    <div class="text-center p-4 bg-gray-50 rounded-lg">
                        <div class="text-gray-600 mb-1">Total Payment</div>
                        <div class="result-value">$<?= number_format($results['total_payment'], 2) ?></div>
                    </div>
                </div>
                
                <h3 class="text-lg font-semibold mb-3">Amortization Schedule</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white rounded-lg overflow-hidden">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="py-2 px-4 text-left">Payment #</th>
                                <th class="py-2 px-4 text-right">Payment</th>
                                <th class="py-2 px-4 text-right">Principal</th>
                                <th class="py-2 px-4 text-right">Interest</th>
                                <th class="py-2 px-4 text-right">Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $balance = $principal;
                            $monthlyRate = ($interestRate / 100) / 12;
                            
                            for ($i = 1; $i <= $results['term_months']; $i++) {
                                $interest = $balance * $monthlyRate;
                                $principalPayment = $results['monthly_payment'] - $interest;
                                $balance -= $principalPayment;
                                
                                // Don't show negative balance
                                if ($balance < 0) $balance = 0;
                                
                                // Highlight current row
                                $rowClass = $i % 2 === 0 ? 'bg-gray-50' : '';
                                
                                // Only show first 5 and last 5 payments to keep table manageable
                                if ($i <= 5 || $i >= $results['term_months'] - 4 || $results['term_months'] <= 10) {
                                    echo "<tr class='$rowClass'>";
                                    echo "<td class='py-2 px-4'>$i</td>";
                                    echo "<td class='py-2 px-4 text-right'>$" . number_format($results['monthly_payment'], 2) . "</td>";
                                    echo "<td class='py-2 px-4 text-right'>$" . number_format($principalPayment, 2) . "</td>";
                                    echo "<td class='py-2 px-4 text-right'>$" . number_format($interest, 2) . "</td>";
                                    echo "<td class='py-2 px-4 text-right'>$" . number_format($balance, 2) . "</td>";
                                    echo "</tr>";
                                }
                                
                                // Show "..." for truncated rows
                                if ($i == 5 && $results['term_months'] > 10) {
                                    echo "<tr><td colspan='5' class='py-1 text-center'>...</td></tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>

<?php include 'footer.php';?>

</html>