<?php include 'header.php';?>

<?php
// Function to extract YouTube thumbnail URLs
function getYouTubeThumbnails($videoId) {
    $thumbnails = [
        'default' => "https://img.youtube.com/vi/$videoId/default.jpg",
        'medium' => "https://img.youtube.com/vi/$videoId/mqdefault.jpg",
        'high' => "https://img.youtube.com/vi/$videoId/hqdefault.jpg",
        'standard' => "https://img.youtube.com/vi/$videoId/sddefault.jpg",
        'maxres' => "https://img.youtube.com/vi/$videoId/maxresdefault.jpg",
    ];
    return $thumbnails;
}

// Handle form submission
$thumbnails = [];
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $videoUrl = $_POST['video_url'];
    // Extract video ID from URL
    parse_str(parse_url($videoUrl, PHP_URL_QUERY), $params);
    $videoId = $params['v'] ?? '';

    if (!empty($videoId)) {
        $thumbnails = getYouTubeThumbnails($videoId);
    } else {
        $error = 'Invalid YouTube video URL.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Thumbnail Downloader</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold text-center mb-6">YouTube Thumbnail Downloader</h1>
        <form method="POST" class="bg-white p-6 rounded-lg shadow-md">
            <div class="mb-4">
                <label for="video_url" class="block text-gray-700 font-bold mb-2">Enter YouTube Video URL:</label>
                <input type="url" name="video_url" id="video_url" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., https://www.youtube.com/watch?v=VIDEO_ID" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300">Get Thumbnails</button>
        </form>
        <?php if (!empty($thumbnails)): ?>
            <div class="mt-6 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-2xl font-bold text-gray-800">Available Thumbnails:</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                    <?php foreach ($thumbnails as $type => $url): ?>
                        <div class="border rounded-lg overflow-hidden shadow-sm">
                            <img src="<?php echo htmlspecialchars($url); ?>" alt="<?php echo htmlspecialchars($type); ?> thumbnail" class="w-full h-auto">
                            <div class="p-4">
                                <p class="text-gray-700 font-bold"><?php echo ucfirst($type); ?></p>
                                <a href="<?php echo htmlspecialchars($url); ?>" download class="mt-2 inline-block bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300">Download</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php elseif (!empty($error)): ?>
            <div class="mt-6 bg-red-100 p-6 rounded-lg shadow-md">
                <p class="text-red-700 text-xl"><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>
<?php include 'footer.php';?>

</html>