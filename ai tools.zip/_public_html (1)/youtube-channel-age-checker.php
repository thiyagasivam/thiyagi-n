<?php include 'header.php'; ?>

<?php
// YouTube Data API Key (Replace with your own API key)
$apiKey = 'AIzaSyBHLsQwaN3hOuuP8YQluOFNi4iu5K_XqEo';

// Function to get channel ID from @username
function getChannelIdFromUsername($username, $apiKey) {
    $apiUrl = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=$username&type=channel&key=$apiKey";
    $response = file_get_contents($apiUrl);
    $data = json_decode($response, true);

    if (isset($data['items'][0]['id']['channelId'])) {
        return $data['items'][0]['id']['channelId'];
    } else {
        return false;
    }
}

// Function to get channel creation date
function getChannelAge($channelId, $apiKey) {
    $apiUrl = "https://www.googleapis.com/youtube/v3/channels?part=snippet&id=$channelId&key=$apiKey";
    $response = file_get_contents($apiUrl);
    $data = json_decode($response, true);

    if (isset($data['items'][0]['snippet']['publishedAt'])) {
        $publishedAt = $data['items'][0]['snippet']['publishedAt'];
        return date('F j, Y', strtotime($publishedAt));
    } else {
        return false;
    }
}

// Handle form submission
$channelAge = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $channelUrl = $_POST['channel_url'];
    $channelId = '';

    // Extract channel ID, custom name, or @username from URL
    if (preg_match('/\/channel\/([a-zA-Z0-9_-]+)/', $channelUrl, $matches)) {
        // Channel ID is provided
        $channelId = $matches[1];
    } elseif (preg_match('/\/c\/([a-zA-Z0-9_-]+)/', $channelUrl, $matches)) {
        // Custom channel name is provided
        $customName = $matches[1];
        $channelId = getChannelIdFromUsername($customName, $apiKey);
        if (!$channelId) {
            $error = 'Unable to resolve custom channel name. Please check the URL and try again.';
        }
    } elseif (preg_match('/\/@([a-zA-Z0-9_-]+)/', $channelUrl, $matches)) {
        // @username is provided
        $username = $matches[1];
        $channelId = getChannelIdFromUsername($username, $apiKey);
        if (!$channelId) {
            $error = 'Unable to resolve @username. Please check the URL and try again.';
        }
    } else {
        $error = 'Invalid YouTube channel URL.';
    }

    // Fetch channel age if channel ID is available
    if (!empty($channelId)) {
        $channelAge = getChannelAge($channelId, $apiKey);
        if (!$channelAge) {
            $error = 'Unable to fetch channel age. Please check the URL and try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Channel Age Checker</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold text-center mb-6">YouTube Channel Age Checker</h1>
        <form method="POST" class="bg-white p-6 rounded-lg shadow-md">
            <div class="mb-4">
                <label for="channel_url" class="block text-gray-700 font-bold mb-2">Enter YouTube Channel URL:</label>
                <input type="url" name="channel_url" id="channel_url" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., https://www.youtube.com/channel/CHANNEL_ID or https://www.youtube.com/c/ChannelName or https://www.youtube.com/@username" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300">Check Channel Age</button>
        </form>
        <?php if (!empty($channelAge)): ?>
            <div class="mt-6 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-2xl font-bold text-gray-800">Channel Creation Date:</h2>
                <p class="text-gray-700 text-xl mt-2"><?php echo htmlspecialchars($channelAge); ?></p>
            </div>
        <?php elseif (!empty($error)): ?>
            <div class="mt-6 bg-red-100 p-6 rounded-lg shadow-md">
                <p class="text-red-700 text-xl"><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>
<?php include 'footer.php'; ?>

</html>