


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
</head>
<body>
    <!-- Content goes here -->
    <main class="flex-grow-1">
        <div class="container social-share">
            <div class="social-share-icons">
                <a href="#" class="facebook" onclick="sharePage('facebook')"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="twitter" onclick="sharePage('twitter')"><i class="fab fa-twitter"></i></a>
                <a href="#" class="pinterest" onclick="sharePage('pinterest')"><i class="fab fa-pinterest-p"></i></a>
                <a href="#" class="linkedin" onclick="sharePage('linkedin')"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" class="reddit" onclick="sharePage('reddit')"><i class="fab fa-reddit-alien"></i></a>
                <a href="#" class="tumblr" onclick="sharePage('tumblr')"><i class="fab fa-tumblr"></i></a>
                <a href="#" class="whatsapp" onclick="sharePage('whatsapp')"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </main>
    

</body>
</html>

