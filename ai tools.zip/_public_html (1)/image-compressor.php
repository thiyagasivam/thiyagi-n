<?php include 'header.php';?>

<?php
// Handle image upload and compression
$error = '';
$success = '';
$compressedFilePath = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    try {
        // Validate upload
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('File upload error: ' . $_FILES['image']['error']);
        }
        
        // Check file type
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $fileType = mime_content_type($_FILES['image']['tmp_name']);
        if (!in_array($fileType, $allowedTypes)) {
            throw new Exception('Only JPG, PNG, GIF, and WebP images are allowed.');
        }
        
        // Check file size (max 10MB)
        if ($_FILES['image']['size'] > 10 * 1024 * 1024) {
            throw new Exception('File size exceeds 10MB limit.');
        }
        
        // Create uploads directory if it doesn't exist
        if (!file_exists('uploads')) {
            mkdir('uploads', 0755, true);
        }
        
        // Generate unique filename
        $originalName = pathinfo($_FILES['image']['name'], PATHINFO_FILENAME);
        $extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $compressedName = 'compressed_' . $originalName . '_' . time() . '.' . $extension;
        $compressedFilePath = 'uploads/' . $compressedName;
        
        // Compression quality (adjust as needed)
        $quality = isset($_POST['quality']) ? (int)$_POST['quality'] : 75;
        $quality = max(10, min(100, $quality)); // Ensure between 10-100
        
        // Compress based on image type
        switch ($fileType) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($_FILES['image']['tmp_name']);
                imagejpeg($image, $compressedFilePath, $quality);
                break;
            case 'image/png':
                $image = imagecreatefrompng($_FILES['image']['tmp_name']);
                imagepalettetotruecolor($image);
                imagealphablending($image, true);
                imagesavealpha($image, true);
                imagepng($image, $compressedFilePath, 9 - round($quality / 12.5)); // PNG quality is 0-9
                break;
            case 'image/gif':
                $image = imagecreatefromgif($_FILES['image']['tmp_name']);
                imagegif($image, $compressedFilePath);
                break;
            case 'image/webp':
                $image = imagecreatefromwebp($_FILES['image']['tmp_name']);
                imagewebp($image, $compressedFilePath, $quality);
                break;
        }
        
        if (isset($image)) {
            imagedestroy($image);
        }
        
        // Calculate savings
        $originalSize = $_FILES['image']['size'];
        $compressedSize = filesize($compressedFilePath);
        $savings = round(100 - ($compressedSize / $originalSize * 100), 2);
        
        $success = "Image compressed successfully! (Saved {$savings}%)";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Compressor Tool</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .dropzone {
            border: 2px dashed #cbd5e0;
            transition: all 0.3s;
        }
        .dropzone:hover, .dropzone.dragover {
            border-color: #4299e1;
            background-color: #ebf8ff;
        }
        .file-info {
            display: none;
        }
        .compression-slider {
            -webkit-appearance: none;
            width: 100%;
            height: 8px;
            border-radius: 4px;
            background: #e2e8f0;
            outline: none;
        }
        .compression-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #4299e1;
            cursor: pointer;
        }
        .compression-slider::-moz-range-thumb {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #4299e1;
            cursor: pointer;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-2">Image Compressor</h1>
            <p class="text-gray-600">Reduce image file size without losing quality</p>
        </div>
        
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <?php if ($error): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                    <p><?php echo htmlspecialchars($error); ?></p>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                    <p><?php echo htmlspecialchars($success); ?></p>
                    <?php if ($compressedFilePath && file_exists($compressedFilePath)): ?>
                        <div class="mt-4">
                            <div class="flex flex-col md:flex-row gap-4">
                                <div class="flex-1">
                                    <h3 class="font-bold mb-2">Original Image</h3>
                                    <img src="<?php echo htmlspecialchars($_FILES['image']['tmp_name']); ?>" class="max-w-full h-auto border rounded" alt="Original image">
                                    <p class="text-sm text-gray-600 mt-1">Size: <?php echo round($_FILES['image']['size'] / 1024); ?> KB</p>
                                </div>
                                <div class="flex-1">
                                    <h3 class="font-bold mb-2">Compressed Image</h3>
                                    <img src="<?php echo htmlspecialchars($compressedFilePath); ?>" class="max-w-full h-auto border rounded" alt="Compressed image">
                                    <p class="text-sm text-gray-600 mt-1">Size: <?php echo round(filesize($compressedFilePath) / 1024); ?> KB</p>
                                </div>
                            </div>
                            <div class="mt-4">
                                <a href="<?php echo htmlspecialchars($compressedFilePath); ?>" download class="inline-block bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded transition duration-200">Download Compressed Image</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <form id="uploadForm" method="POST" enctype="multipart/form-data" class="space-y-4">
                <div class="dropzone rounded-lg p-8 text-center cursor-pointer" id="dropzone">
                    <input type="file" name="image" id="image" class="hidden" accept="image/*">
                    <div class="flex flex-col items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                        </svg>
                        <p class="text-lg font-medium text-gray-700">Drag and drop your image here</p>
                        <p class="text-sm text-gray-500 mt-1">or click to browse files</p>
                        <p class="text-xs text-gray-400 mt-2">Supports JPG, PNG, GIF, WebP (Max 10MB)</p>
                    </div>
                </div>
                
                <div id="fileInfo" class="file-info bg-gray-50 p-4 rounded-lg">
                    <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <span id="fileName" class="font-medium"></span>
                        <span id="fileSize" class="text-gray-500 text-sm ml-auto"></span>
                    </div>
                </div>
                
                <div class="space-y-2">
                    <label for="quality" class="block text-sm font-medium text-gray-700">Compression Quality: <span id="qualityValue">75</span>%</label>
                    <input type="range" id="quality" name="quality" min="10" max="100" value="75" class="compression-slider">
                    <div class="flex justify-between text-xs text-gray-500">
                        <span>Smaller file</span>
                        <span>Better quality</span>
                    </div>
                </div>
                
                <button type="submit" id="compressBtn" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-4 rounded-lg transition duration-200 flex items-center justify-center" disabled>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4" />
                    </svg>
                    Compress Image
                </button>
            </form>
        </div>
        
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">How to Compress Images</h2>
            <ol class="list-decimal list-inside space-y-2 text-gray-700">
                <li>Upload your image by dragging and dropping or clicking to browse</li>
                <li>Adjust the compression quality slider (higher = better quality but larger file)</li>
                <li>Click "Compress Image" to process your file</li>
                <li>Download your compressed image</li>
            </ol>
        </div>
    </div>

    <script>
        // Handle drag and drop
        const dropzone = document.getElementById('dropzone');
        const fileInput = document.getElementById('image');
        const fileInfo = document.getElementById('fileInfo');
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const compressBtn = document.getElementById('compressBtn');
        const qualitySlider = document.getElementById('quality');
        const qualityValue = document.getElementById('qualityValue');
        
        // Update quality value display
        qualitySlider.addEventListener('input', () => {
            qualityValue.textContent = qualitySlider.value;
        });
        
        // Click on dropzone triggers file input
        dropzone.addEventListener('click', () => {
            fileInput.click();
        });
        
        // Handle drag over
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
        
        // Handle drag leave
        dropzone.addEventListener('dragleave', () => {
            dropzone.classList.remove('dragover');
        });
        
        // Handle drop
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                updateFileInfo();
            }
        });
        
        // Handle file selection
        fileInput.addEventListener('change', updateFileInfo);
        
        function updateFileInfo() {
            if (fileInput.files.length) {
                const file = fileInput.files[0];
                fileName.textContent = file.name;
                fileSize.textContent = formatFileSize(file.size);
                fileInfo.style.display = 'block';
                compressBtn.disabled = false;
            } else {
                fileInfo.style.display = 'none';
                compressBtn.disabled = true;
            }
        }
        
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i];
        }
    </script>
</body>

<?php include 'footer.php';?>


</html>