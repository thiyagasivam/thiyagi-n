<?php
/*
 * Modern Holiday Calendar
 * Single-file version with:
 * - Mobile-responsive design
 * - Dark/light mode toggle
 * - Country-specific holiday pages
 * - Animated UI elements
 * - Calendarific API integration
 */

$api_key = "ISiGbL8Ya0Iz6d3GoVSYvfulH03dITcB";
$current_year = date('Y');
$default_country = 'US';

// Get country from URL or use default
$country = isset($_GET['country']) ? strtoupper($_GET['country']) : $default_country;
$year = isset($_GET['year']) ? $_GET['year'] : $current_year;

// Fetch holidays from API
function getHolidays($api_key, $country, $year) {
    $url = "https://calendarific.com/api/v2/holidays?api_key=$api_key&country=$country&year=$year";
    $data = @file_get_contents($url);
    return $data ? json_decode($data, true) : null;
}

$holidays_data = getHolidays($api_key, $country, $year);
$country_name = $holidays_data['response']['holidays'][0]['country']['name'] ?? $country;
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($country_name) ?> Holidays <?= $year ?> | Global Holiday Calendar</title>
    <meta name="description" content="Public holidays and observances in <?= htmlspecialchars($country_name) ?> for <?= $year ?>">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            light: '#4f46e5',
                            dark: '#7c3aed'
                        }
                    },
                    animation: {
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }
        .holiday-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        @media (max-width: 640px) {
            .holiday-card {
                width: 100%;
            }
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200 transition-colors duration-200">
    <header class="bg-gradient-to-r from-primary-light to-primary-dark text-white shadow-lg">
        <div class="container mx-auto px-4 py-6">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center mb-4 md:mb-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <h1 class="text-2xl md:text-3xl font-bold">Global Holiday Calendar</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <button id="theme-toggle" class="p-2 rounded-full bg-white/10 hover:bg-white/20 transition">
                        <svg id="theme-icon" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path id="theme-path" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                    </button>
                    <div class="relative">
                        <select id="country-select" class="bg-white/10 border-0 text-white rounded-md pl-4 pr-8 py-2 appearance-none focus:ring-2 focus:ring-white">
                            <option value="US" <?= $country === 'US' ? 'selected' : '' ?>>United States</option>
                            <option value="GB" <?= $country === 'GB' ? 'selected' : '' ?>>United Kingdom</option>
                            <option value="IN" <?= $country === 'IN' ? 'selected' : '' ?>>India</option>
                            <option value="CA" <?= $country === 'CA' ? 'selected' : '' ?>>Canada</option>
                            <option value="AU" <?= $country === 'AU' ? 'selected' : '' ?>>Australia</option>
                        </select>
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white">
                            <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="container mx-auto px-4 py-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <h2 class="text-2xl font-bold mb-4 md:mb-0">
                <?= htmlspecialchars($country_name) ?> Holidays <?= $year ?>
            </h2>
            <div class="flex space-x-2">
                <input type="number" id="year-select" min="2000" max="<?= $current_year + 5 ?>" value="<?= $year ?>" 
                    class="w-24 px-3 py-2 border rounded-md dark:bg-gray-800 dark:border-gray-700">
                <button onclick="updateCalendar()" class="px-4 py-2 bg-primary-light dark:bg-primary-dark text-white rounded-md hover:opacity-90 transition">
                    Go
                </button>
            </div>
        </div>

        <?php if ($holidays_data && isset($holidays_data['response']['holidays'])): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($holidays_data['response']['holidays'] as $holiday): ?>
                    <div class="holiday-card bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-all duration-300">
                        <div class="p-6">
                            <div class="flex justify-between items-start">
                                <h3 class="text-xl font-semibold mb-2"><?= htmlspecialchars($holiday['name']) ?></h3>
                                <span class="inline-block px-2 py-1 text-xs font-medium rounded-full 
                                    <?= in_array('national', $holiday['type']) ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' ?>">
                                    <?= ucfirst($holiday['type'][0]) ?>
                                </span>
                            </div>
                            <p class="text-gray-600 dark:text-gray-400 mb-4">
                                <?= date('F j, Y', strtotime($holiday['date']['iso'])) ?>
                            </p>
                            <?php if (!empty($holiday['description'])): ?>
                                <p class="text-gray-700 dark:text-gray-300 mb-4">
                                    <?= htmlspecialchars($holiday['description']) ?>
                                </p>
                            <?php endif; ?>
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-500 dark:text-gray-400">
                                    <?= $holiday['locations'] === 'All' ? 'Countrywide' : $holiday['locations'] ?>
                                </span>
                                <button onclick="shareHoliday('<?= htmlspecialchars($holiday['name']) ?>', '<?= $holiday['date']['iso'] ?>')" 
                                    class="p-2 text-gray-500 hover:text-primary-light dark:hover:text-primary-dark transition">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-12">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 class="text-xl font-medium text-gray-600 dark:text-gray-400">No holidays found</h3>
                <p class="text-gray-500 dark:text-gray-500 mt-2">Try selecting a different country or year</p>
            </div>
        <?php endif; ?>
    </main>

    <footer class="bg-gray-100 dark:bg-gray-800 py-8 mt-12">
        <div class="container mx-auto px-4">
            <div class="text-center text-gray-600 dark:text-gray-400">
                <p>© <?= date('Y') ?> Global Holiday Calendar. Powered by Calendarific API.</p>
            </div>
        </div>
    </footer>

    <script>
        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const themePath = document.getElementById('theme-path');
        
        if (localStorage.getItem('color-theme') {
            document.documentElement.classList.add(localStorage.getItem('color-theme'));
        } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.documentElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            if (document.documentElement.classList.contains('dark')) {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('color-theme', 'light');
                themePath.setAttribute('d', 'M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z');
            } else {
                document.documentElement.classList.add('dark');
                localStorage.setItem('color-theme', 'dark');
                themePath.setAttribute('d', 'M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z');
            }
        });

        // Country select
        document.getElementById('country-select').addEventListener('change', function() {
            const country = this.value;
            window.location.href = `?country=${country}&year=<?= $year ?>`;
        });

        // Update calendar
        function updateCalendar() {
            const year = document.getElementById('year-select').value;
            window.location.href = `?country=<?= $country ?>&year=${year}`;
        }

        // Share holiday
        function shareHoliday(name, date) {
            const text = `Celebrate ${name} on ${new Date(date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`;
            if (navigator.share) {
                navigator.share({
                    title: name,
                    text: text,
                    url: window.location.href
                }).catch(err => {
                    console.log('Error sharing:', err);
                });
            } else {
                // Fallback for desktop
                const shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(window.location.href)}`;
                window.open(shareUrl, '_blank');
            }
        }
    </script>
</body>
</html>