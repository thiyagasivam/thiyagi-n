<?php include 'header.php';?>
<?php
// Handle file upload and reverse image search
$results = [];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Validate image file
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedType = finfo_file($fileInfo, $_FILES['image']['tmp_name']);
        
        if (in_array($detectedType, $allowedTypes)) {
            // Process the image (in a real implementation, you would call Google's API here)
            $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
            $uploadPath = 'uploads/' . $fileName;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
                // Simulate API results - in production you would call Google Reverse Image Search API
                $results = [
                    [
                        'title' => 'Similar Image 1',
                        'url' => '#',
                        'source' => 'Example.com',
                        'thumbnail' => 'https://via.placeholder.com/150'
                    ],
                    [
                        'title' => 'Similar Image 2',
                        'url' => '#',
                        'source' => 'SampleSite.org',
                        'thumbnail' => 'https://via.placeholder.com/150'
                    ],
                    [
                        'title' => 'Similar Image 3',
                        'url' => '#',
                        'source' => 'TestImage.net',
                        'thumbnail' => 'https://via.placeholder.com/150'
                    ]
                ];
            } else {
                $error = 'Failed to upload image.';
            }
        } else {
            $error = 'Invalid file type. Only JPG, PNG, and GIF are allowed.';
        }
    } elseif (isset($_POST['image_url']) && !empty($_POST['image_url'])) {
        // Process image URL (in a real implementation, you would call Google's API here)
        $imageUrl = filter_var($_POST['image_url'], FILTER_VALIDATE_URL);
        
        if ($imageUrl) {
            // Simulate API results - in production you would call Google Reverse Image Search API
            $results = [
                [
                    'title' => 'Similar Image from URL 1',
                    'url' => '#',
                    'source' => 'Example.com',
                    'thumbnail' => 'https://via.placeholder.com/150'
                ],
                [
                    'title' => 'Similar Image from URL 2',
                    'url' => '#',
                    'source' => 'SampleSite.org',
                    'thumbnail' => 'https://via.placeholder.com/150'
                ]
            ];
        } else {
            $error = 'Invalid image URL.';
        }
    } else {
        $error = 'Please provide an image file or URL.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reverse Image Search - Find Similar Images Online</title>
    <meta name="description" content="Free online reverse image search tool. Upload an image or paste image URL to find similar images across the web.">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .tab-button {
            transition: all 0.3s ease;
        }
        .tab-button.active {
            background-color: #3b82f6;
            color: white;
        }
        .drag-drop-area {
            border: 2px dashed #cbd5e0;
            transition: all 0.3s ease;
        }
        .drag-drop-area:hover, .drag-drop-area.dragover {
            border-color: #3b82f6;
            background-color: #f0f7ff;
        }
        .result-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8 max-w-6xl">
        <header class="text-center mb-10">
            <h1 class="text-3xl md:text-4xl font-bold text-gray-800 mb-3">Reverse Image Search</h1>
            <p class="text-lg text-gray-600">Upload an image or paste image URL to find similar images across the web</p>
        </header>

        <div class="bg-white rounded-xl shadow-md overflow-hidden mb-10">
            <div class="flex border-b">
                <button id="upload-tab" class="tab-button active flex-1 py-4 px-6 text-center font-medium">Upload Image</button>
                <button id="url-tab" class="tab-button flex-1 py-4 px-6 text-center font-medium">Paste Image URL</button>
            </div>

            <div class="p-6">
                <!-- Upload Image Tab -->
                <div id="upload-tab-content">
                    <form id="upload-form" method="POST" enctype="multipart/form-data" class="space-y-4">
                        <div id="drag-drop-area" class="drag-drop-area rounded-lg p-12 text-center cursor-pointer">
                            <input type="file" id="image-upload" name="image" accept="image/*" class="hidden">
                            <div class="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                </svg>
                            </div>
                            <h3 class="text-lg font-medium text-gray-700 mb-1">Drag & Drop your image here</h3>
                            <p class="text-gray-500 mb-4">or</p>
                            <button type="button" id="browse-btn" class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-6 rounded-lg transition duration-300">
                                Browse Files
                            </button>
                            <p class="text-sm text-gray-500 mt-4">Supports: JPG, PNG, GIF (Max: 5MB)</p>
                        </div>
                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                            Search Image
                        </button>
                    </form>
                </div>

                <!-- URL Tab -->
                <div id="url-tab-content" class="hidden">
                    <form id="url-form" method="POST" class="space-y-4">
                        <div class="space-y-2">
                            <label for="image_url" class="block text-sm font-medium text-gray-700">Image URL</label>
                            <input type="url" id="image_url" name="image_url" placeholder="https://example.com/image.jpg" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                            Search Image
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <?php if (!empty($error)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-8 rounded">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>

        <?php if (!empty($results)): ?>
            <div class="mb-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">Search Results</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($results as $result): ?>
                        <div class="result-item bg-white rounded-lg shadow-md overflow-hidden transition duration-300">
                            <a href="<?php echo htmlspecialchars($result['url']); ?>" target="_blank" rel="noopener noreferrer" class="block">
                                <img src="<?php echo htmlspecialchars($result['thumbnail']); ?>" alt="<?php echo htmlspecialchars($result['title']); ?>" class="w-full h-48 object-cover">
                                <div class="p-4">
                                    <h3 class="font-medium text-gray-800 mb-1"><?php echo htmlspecialchars($result['title']); ?></h3>
                                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($result['source']); ?></p>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-xl shadow-md p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">About Reverse Image Search</h2>
            <div class="prose text-gray-700">
                <p>Our reverse image search tool helps you find similar images across the web. Simply upload an image or paste an image URL, and our system will search for visually similar images.</p>
                <p class="mt-2">This tool is useful for:</p>
                <ul class="list-disc pl-5 space-y-1">
                    <li>Finding higher resolution versions of an image</li>
                    <li>Discovering where an image appears online</li>
                    <li>Identifying objects or landmarks in photos</li>
                    <li>Checking for copyright violations</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Tab switching functionality
        const uploadTab = document.getElementById('upload-tab');
        const urlTab = document.getElementById('url-tab');
        const uploadTabContent = document.getElementById('upload-tab-content');
        const urlTabContent = document.getElementById('url-tab-content');

        uploadTab.addEventListener('click', () => {
            uploadTab.classList.add('active');
            urlTab.classList.remove('active');
            uploadTabContent.classList.remove('hidden');
            urlTabContent.classList.add('hidden');
        });

        urlTab.addEventListener('click', () => {
            urlTab.classList.add('active');
            uploadTab.classList.remove('active');
            urlTabContent.classList.remove('hidden');
            uploadTabContent.classList.add('hidden');
        });

        // Drag and drop functionality
        const dragDropArea = document.getElementById('drag-drop-area');
        const fileInput = document.getElementById('image-upload');
        const browseBtn = document.getElementById('browse-btn');

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dragDropArea.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            dragDropArea.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dragDropArea.addEventListener(eventName, unhighlight, false);
        });

        function highlight() {
            dragDropArea.classList.add('dragover');
        }

        function unhighlight() {
            dragDropArea.classList.remove('dragover');
        }

        dragDropArea.addEventListener('drop', handleDrop, false);
        browseBtn.addEventListener('click', () => fileInput.click());

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            // You could add feedback showing the file name here
        }
    </script>
</body>

<?php include 'footer.php';?>


</html>