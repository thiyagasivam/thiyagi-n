<?php include 'header.php';?>

<?php
// JSON Viewer Tool
$jsonInput = '';
$formattedJson = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jsonInput = $_POST['json'] ?? '';
    
    if (!empty($jsonInput)) {
        try {
            $decoded = json_decode($jsonInput);
            if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON: ' . json_last_error_msg());
            }
            $formattedJson = json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    } else {
        $error = 'Please enter JSON data';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JSON Viewer Tool | Format and Validate JSON Data</title>
    <meta name="description" content="Free online JSON viewer that formats and validates JSON data. Beautify and analyze JSON structures easily.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .json-container {
            position: relative;
        }
        .copy-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 10;
        }
        #jsonOutput {
            min-height: 300px;
            background-color: #f8f9fa;
            font-family: monospace;
            white-space: pre;
            overflow-x: auto;
        }
        .keyword { color: #d63384; }
        .string { color: #20c997; }
        .number { color: #fd7e14; }
        .boolean { color: #6610f2; }
        .null { color: #6c757d; }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h1 class="h4 mb-0">JSON Viewer Tool</h1>
                    </div>
                    <div class="card-body">
                        <form method="post">
                            <div class="mb-3">
                                <label for="jsonInput" class="form-label">Enter JSON Data:</label>
                                <textarea class="form-control font-monospace" id="jsonInput" name="json" rows="10" placeholder='{"example": "JSON data", "numbers": [1, 2, 3]}'><?= htmlspecialchars($jsonInput) ?></textarea>
                            </div>
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="submit" class="btn btn-primary me-md-2">Format JSON</button>
                                <button type="reset" class="btn btn-outline-secondary">Clear</button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if (!empty($formattedJson) || !empty($error)): ?>
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h2 class="h5 mb-0">Formatted JSON Output</h2>
                    </div>
                    <div class="card-body position-relative p-0">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger m-3"><?= htmlspecialchars($error) ?></div>
                        <?php else: ?>
                            <button id="copyBtn" class="btn btn-sm btn-outline-primary copy-btn" title="Copy to clipboard">
                                <i class="bi bi-clipboard"></i> Copy
                            </button>
                            <pre id="jsonOutput" class="p-3 mb-0"><?= htmlspecialchars($formattedJson) ?></pre>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="h5">About JSON Viewer Tool</h2>
                        <p>This free online JSON viewer helps you format, validate, and analyze JSON data. It provides syntax highlighting and proper indentation to make your JSON structures more readable.</p>
                        <h3 class="h6">Features:</h3>
                        <ul>
                            <li>Formats messy JSON into human-readable structure</li>
                            <li>Validates JSON syntax and highlights errors</li>
                            <li>Syntax highlighting for different JSON elements</li>
                            <li>Copy to clipboard functionality</li>
                            <li>Works with complex nested JSON structures</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Syntax highlighting
        function highlightJson() {
            const output = document.getElementById('jsonOutput');
            if (!output) return;
            
            let text = output.innerHTML;
            // Highlight keywords
            text = text.replace(/"([^"]+)":/g, '"<span class="string">$1</span>":');
            text = text.replace(/: ("[^"]*")/g, ': <span class="string">$1</span>');
            text = text.replace(/: (true|false)/g, ': <span class="boolean">$1</span>');
            text = text.replace(/: (null)/g, ': <span class="null">$1</span>');
            text = text.replace(/: (\d+)/g, ': <span class="number">$1</span>');
            text = text.replace(/"([^"]+)"/g, '<span class="string">"$1"</span>');
            output.innerHTML = text;
        }
        
        // Copy to clipboard
        document.getElementById('copyBtn')?.addEventListener('click', function() {
            const output = document.getElementById('jsonOutput');
            navigator.clipboard.writeText(output.innerText).then(() => {
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="bi bi-check"></i> Copied!';
                setTimeout(() => {
                    this.innerHTML = originalText;
                }, 2000);
            });
        });
        
        // Highlight on page load
        document.addEventListener('DOMContentLoaded', highlightJson);
    </script>
</body>
<?php include 'footer.php';?>


</html>