<?php include 'header.php'; ?>

    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Word Counter</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border: none;
            border-radius: 10px;
        }
        textarea {
            resize: none;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Word Counter</h1>
        <div class="card shadow">
            <div class="card-body">
                <form method="POST">
                    <div class="form-group">
                        <textarea class="form-control" name="text" rows="10" placeholder="Paste your text here..."><?php echo isset($_POST['text']) ? htmlspecialchars($_POST['text']) : ''; ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Count Words</button>
                </form>
                <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $text = $_POST['text'];
                    $wordCount = str_word_count($text);
                    $charCount = strlen($text);
                    echo "<div class='mt-4'>
                            <h4>Results:</h4>
                            <p><strong>Word Count:</strong> $wordCount</p>
                            <p><strong>Character Count:</strong> $charCount</p>
                          </div>";
                }
                ?>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS (optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

<?php include 'footer.php'; ?>

</html>