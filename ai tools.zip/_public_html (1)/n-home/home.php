<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Text Tools</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .tool-card {
            display: flex;
            align-items: center;
            gap: 10px;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: 0.3s ease-in-out;
            cursor: pointer;
        }
        .tool-card:hover {
            transform: translateY(-3px);
            background-color: #f1f1f1;
        }
        .tool-card i {
            font-size: 24px; /* Adjust icon size */
            color: #007bff; /* Change icon color */
        }
        .tools-container {
            max-width: 900px;
            margin: auto;
        }
    </style>
</head>
<body>

    <div class="container my-4">
        <h2 class="text-center fw-bold">Text Tools</h2>
        <div class="row tools-container g-3">
            <div class="col-md-6 col-lg-4">
                <div class="tool-card">
                    <i class="fas fa-edit"></i> 
                    <span>Article Rewriter</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="tool-card">
                    <i class="fas fa-sort-alpha-up"></i> 
                    <span>Word Counter</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="tool-card">
                    <i class="fas fa-undo"></i> 
                    <span>Backwards Text Generator</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="tool-card">
                    <i class="fas fa-hashtag"></i> 
                    <span>Text to Hashtags Converter</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="tool-card">
                    <i class="fas fa-exchange-alt"></i> 
                    <span>Text Compare</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="tool-card">
                    <i class="fas fa-link"></i> 
                    <span>Text to Slug Converter</span>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
