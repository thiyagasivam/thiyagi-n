<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Text Tools</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .tool-card {
            display: flex;
            align-items: center;
            gap: 10px;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: 0.3s ease-in-out;
        }
        .tool-card:hover {
                            box-shadow: 0px 0px 8px 4px rgba(23, 49, 76, 0.3);
            
            /*transform: translateY(-3px);*/
        }
        .tool-card img {
            width: 40px;
            height: 40px;
        }
        .tools-container {
            /*max-width: 900px;*/
            margin: auto;
        }
        
        .card-bg{
                box-shadow: 0 0 2rem 0 rgba(136, 152, 170, .15);
                border: 1px solid #e6e6e6;
                padding-top: 2rem;
                padding-bottom: 3rem;
                border-radius: 10px;
                }
        .tool-card img {
                width: 40px;
                height: 40px;
}

 .tool-card i {
            font-size: 24px; /* Adjust icon size */
            color: #007bff; /* Change icon color */
        }
    </style>
</head>
<body>

    <div class="container my-4 card-bg">
        <h2 class="text-center fw-bold">Text Tools</h2>
        <div class="row tools-container g-3">
            <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon1.png" alt="Icon">-->
                                        <i class="fas fa-edit"></i> 
                    <span>Article Rewriter</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon2.png" alt="Icon">-->
                                        <i class="fas fa-sort-alpha-up"></i> 
                    <span>Word Counter</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon3.png" alt="Icon">-->
                                        <i class="fas fa-undo"></i> 
                    <span>Backwards Text Generator</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon4.png" alt="Icon">-->
                                        <i class="fas fa-hashtag"></i> 
                    <span>Text to Hashtags Converter</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon5.png" alt="Icon">-->
                                        <i class="fas fa-exchange-alt"></i> 
                    <span>Text Compare</span>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon6.png" alt="Icon">-->
                                        <i class="fas fa-link"></i> 
                    <span>Text to Slug Converter</span>
                </div>
            </div>
              <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon6.png" alt="Icon">-->
                    <i class="far fa-link"></i>
                    <span>Text to Slug Converter</span>
                </div>
            </div>
              <div class="col-md-6 col-lg-3">
                <div class="tool-card">
                    <!--<img src="icon6.png" alt="Icon">-->
                    <i class="fas fa-edit"></i>
                    <span>Article Rewriter</span>
                </div>
            </div>
        </div>
    </div>
    
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
