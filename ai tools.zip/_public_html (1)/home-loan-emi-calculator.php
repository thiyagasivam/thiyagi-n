<?php include 'header.php';?>

<?php
// Function to calculate EMI
function calculateEMI($principal, $rate, $tenure) {
    $monthlyRate = ($rate / 12) / 100;
    $termInMonths = $tenure * 12;
    
    $emi = ($principal * $monthlyRate * pow(1 + $monthlyRate, $termInMonths)) / 
           (pow(1 + $monthlyRate, $termInMonths) - 1);
    
    return round($emi, 2);
}

// Function to calculate total payment
function calculateTotalPayment($emi, $tenure) {
    return round($emi * $tenure * 12, 2);
}

// Function to calculate total interest
function calculateTotalInterest($totalPayment, $principal) {
    return round($totalPayment - $principal, 2);
}

// Handle form submission
$emi = $totalPayment = $totalInterest = 0;
$principal = isset($_POST['principal']) ? (float)$_POST['principal'] : 2000000;
$rate = isset($_POST['rate']) ? (float)$_POST['rate'] : 8.5;
$tenure = isset($_POST['tenure']) ? (int)$_POST['tenure'] : 20;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emi = calculateEMI($principal, $rate, $tenure);
    $totalPayment = calculateTotalPayment($emi, $tenure);
    $totalInterest = calculateTotalInterest($totalPayment, $principal);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Loan EMI Calculator | Calculate Your Mortgage Payments</title>
    <meta name="description" content="Free online home loan EMI calculator to estimate your monthly mortgage payments. Calculate principal, interest and total payment for your home loan.">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .slider-thumb::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: #3b82f6;
            cursor: pointer;
        }
        .slider-thumb::-moz-range-thumb {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: #3b82f6;
            cursor: pointer;
        }
        .chart-container {
            height: 300px;
        }
        @media (min-width: 768px) {
            .chart-container {
                height: 400px;
            }
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8 max-w-6xl">
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Home Loan EMI Calculator</h1>
            <p class="text-gray-600 max-w-2xl mx-auto">Calculate your monthly EMI, total payment and interest for home loans</p>
        </div>

        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Calculator Form -->
            <div class="w-full lg:w-1/2 bg-white p-6 rounded-xl shadow-md">
                <form method="POST" id="emiForm">
                    <!-- Loan Amount -->
                    <div class="mb-8">
                        <div class="flex justify-between items-center mb-2">
                            <label for="principal" class="block text-gray-700 font-medium">Loan Amount</label>
                            <span class="text-gray-900 font-bold">₹ 
                                <input type="number" id="principalDisplay" class="w-24 border-0 p-0 text-right font-bold focus:ring-0" value="<?php echo number_format($principal, 0); ?>" readonly>
                            </span>
                        </div>
                        <input type="range" id="principal" name="principal" min="500000" max="50000000" step="100000" 
                               value="<?php echo $principal; ?>" class="w-full slider-thumb h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer">
                        <div class="flex justify-between text-xs text-gray-500 mt-1">
                            <span>₹5L</span>
                            <span>₹50L</span>
                            <span>₹1Cr</span>
                            <span>₹2Cr</span>
                            <span>₹5Cr</span>
                        </div>
                    </div>

                    <!-- Interest Rate -->
                    <div class="mb-8">
                        <div class="flex justify-between items-center mb-2">
                            <label for="rate" class="block text-gray-700 font-medium">Interest Rate</label>
                            <span class="text-gray-900 font-bold">
                                <input type="number" id="rateDisplay" class="w-16 border-0 p-0 text-right font-bold focus:ring-0" value="<?php echo $rate; ?>" readonly> %
                            </span>
                        </div>
                        <input type="range" id="rate" name="rate" min="5" max="20" step="0.1" 
                               value="<?php echo $rate; ?>" class="w-full slider-thumb h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer">
                        <div class="flex justify-between text-xs text-gray-500 mt-1">
                            <span>5%</span>
                            <span>8%</span>
                            <span>12%</span>
                            <span>16%</span>
                            <span>20%</span>
                        </div>
                    </div>

                    <!-- Loan Tenure -->
                    <div class="mb-8">
                        <div class="flex justify-between items-center mb-2">
                            <label for="tenure" class="block text-gray-700 font-medium">Loan Tenure</label>
                            <span class="text-gray-900 font-bold">
                                <input type="number" id="tenureDisplay" class="w-16 border-0 p-0 text-right font-bold focus:ring-0" value="<?php echo $tenure; ?>" readonly> Yrs
                            </span>
                        </div>
                        <input type="range" id="tenure" name="tenure" min="1" max="30" step="1" 
                               value="<?php echo $tenure; ?>" class="w-full slider-thumb h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer">
                        <div class="flex justify-between text-xs text-gray-500 mt-1">
                            <span>1Yr</span>
                            <span>5Yrs</span>
                            <span>10Yrs</span>
                            <span>20Yrs</span>
                            <span>30Yrs</span>
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                        Calculate EMI
                    </button>
                </form>
            </div>

            <!-- Results -->
            <div class="w-full lg:w-1/2">
                <div class="bg-white p-6 rounded-xl shadow-md mb-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">EMI Breakdown</h2>
                    
                    <div class="grid grid-cols-3 gap-4 text-center mb-6">
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <div class="text-blue-600 text-sm font-medium">Monthly EMI</div>
                            <div class="text-2xl font-bold text-gray-800">₹<?php echo number_format($emi, 0); ?></div>
                        </div>
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <div class="text-blue-600 text-sm font-medium">Total Interest</div>
                            <div class="text-2xl font-bold text-gray-800">₹<?php echo number_format($totalInterest, 0); ?></div>
                        </div>
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <div class="text-blue-600 text-sm font-medium">Total Payment</div>
                            <div class="text-2xl font-bold text-gray-800">₹<?php echo number_format($totalPayment, 0); ?></div>
                        </div>
                    </div>

                    <!-- Pie Chart Placeholder -->
                    <div class="chart-container">
                        <canvas id="emiChart"></canvas>
                    </div>
                </div>

                <!-- Amortization Table -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Amortization Schedule</h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white">
                            <thead>
                                <tr class="bg-gray-100 text-gray-600 text-sm">
                                    <th class="py-2 px-4 text-left">Year</th>
                                    <th class="py-2 px-4 text-right">Principal</th>
                                    <th class="py-2 px-4 text-right">Interest</th>
                                    <th class="py-2 px-4 text-right">Balance</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-700">
                                <?php
                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                    $balance = $principal;
                                    $monthlyRate = ($rate / 12) / 100;
                                    $termInMonths = $tenure * 12;
                                    
                                    for ($year = 1; $year <= $tenure; $year++) {
                                        $yearlyPrincipal = 0;
                                        $yearlyInterest = 0;
                                        
                                        for ($month = 1; $month <= 12; $month++) {
                                            $interest = $balance * $monthlyRate;
                                            $principalPaid = $emi - $interest;
                                            
                                            $yearlyPrincipal += $principalPaid;
                                            $yearlyInterest += $interest;
                                            $balance -= $principalPaid;
                                            
                                            if ($balance < 0) $balance = 0;
                                        }
                                        
                                        echo '<tr class="border-t border-gray-200">';
                                        echo '<td class="py-2 px-4">Year ' . $year . '</td>';
                                        echo '<td class="py-2 px-4 text-right">₹' . number_format($yearlyPrincipal, 0) . '</td>';
                                        echo '<td class="py-2 px-4 text-right">₹' . number_format($yearlyInterest, 0) . '</td>';
                                        echo '<td class="py-2 px-4 text-right">₹' . number_format($balance, 0) . '</td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="4" class="py-4 text-center text-gray-500">Enter loan details to see amortization schedule</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart.js for visualization -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Update slider display values
        document.getElementById('principal').addEventListener('input', function() {
            document.getElementById('principalDisplay').value = parseInt(this.value).toLocaleString('en-IN');
        });
        document.getElementById('rate').addEventListener('input', function() {
            document.getElementById('rateDisplay').value = this.value;
        });
        document.getElementById('tenure').addEventListener('input', function() {
            document.getElementById('tenureDisplay').value = this.value;
        });

        // Initialize chart if EMI is calculated
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && $emi > 0): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('emiChart').getContext('2d');
            const emiChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Principal', 'Interest'],
                    datasets: [{
                        data: [<?php echo $principal; ?>, <?php echo $totalInterest; ?>],
                        backgroundColor: ['#3b82f6', '#93c5fd'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    label += '₹' + context.raw.toLocaleString('en-IN');
                                    return label;
                                }
                            }
                        }
                    },
                    cutout: '70%'
                }
            });
        });
        <?php endif; ?>
    </script>
</body>

<?php include 'footer.php';?>

</html>