<?php include 'header.php';?>

<?php
// YouTube Video Downloader
error_reporting(0);

// Function to sanitize input
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Function to extract video ID from URL
function extractVideoId($url) {
    $pattern = '/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\//i';
    preg_match($pattern, $url, $matches);
    return isset($matches[1]) ? $matches[1] : '';
}

// Function to get video info using YouTube API
function getVideoInfo($videoId) {
    $apiUrl = "https://www.youtube.com/get_video_info?video_id=$videoId&el=embedded&ps=default&eurl=&gl=US&hl=en";
    $response = @file_get_contents($apiUrl);
    parse_str($response, $videoInfo);
    return $videoInfo;
}

// Function to parse video formats
function parseFormats($videoInfo) {
    if (!isset($videoInfo['url_encoded_fmt_stream_map'])) {
        return [];
    }
    
    $formats = explode(',', $videoInfo['url_encoded_fmt_stream_map']);
    $parsedFormats = [];
    
    foreach ($formats as $format) {
        parse_str($format, $formatInfo);
        $type = explode(';', $formatInfo['type']);
        $parsedFormats[] = [
            'url' => $formatInfo['url'],
            'quality' => isset($formatInfo['quality_label']) ? $formatInfo['quality_label'] : '',
            'type' => $type[0],
            'itag' => $formatInfo['itag']
        ];
    }
    
    return $parsedFormats;
}

// Handle form submission
$error = '';
$videoInfo = [];
$formats = [];
$thumbnail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $videoUrl = sanitizeInput($_POST['video_url']);
    $videoId = extractVideoId($videoUrl);
    
    if (empty($videoId)) {
        $error = 'Invalid YouTube URL. Please enter a valid YouTube video URL.';
    } else {
        $videoInfo = getVideoInfo($videoId);
        if (isset($videoInfo['errorcode'])) {
            $error = 'Error: ' . $videoInfo['reason'];
        } else {
            $formats = parseFormats($videoInfo);
            $thumbnail = "https://img.youtube.com/vi/$videoId/maxresdefault.jpg";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Video Downloader | Download Videos in HD Quality</title>
    <meta name="description" content="Free online YouTube video downloader. Download videos in MP4, 3GP, 720p, 1080p, 4K quality without registration.">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .download-btn {
            transition: all 0.3s ease;
        }
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        .video-card {
            transition: all 0.3s ease;
        }
        .video-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="gradient-bg text-white py-6 shadow-lg">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <h1 class="text-3xl font-bold mb-4 md:mb-0">YouTube Video Downloader</h1>
                <div class="flex items-center space-x-2">
                    <span class="hidden md:block">100% Free</span>
                    <span class="bg-white text-purple-700 px-3 py-1 rounded-full text-sm font-semibold">No Registration</span>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <div class="max-w-3xl mx-auto">
            <!-- Download Form -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Download YouTube Videos</h2>
                <form method="POST" class="space-y-4">
                    <div>
                        <label for="video_url" class="block text-gray-700 font-medium mb-2">YouTube Video URL:</label>
                        <input type="url" name="video_url" id="video_url" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent" 
                               placeholder="https://www.youtube.com/watch?v=..." required>
                    </div>
                    <button type="submit" 
                            class="w-full gradient-bg text-white font-bold py-3 px-4 rounded-lg download-btn">
                        Get Download Links
                    </button>
                </form>
            </div>

            <!-- Results Section -->
            <?php if (!empty($error)): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-8 rounded">
                    <p><?php echo $error; ?></p>
                </div>
            <?php elseif (!empty($formats)): ?>
                <div class="bg-white rounded-xl shadow-md overflow-hidden video-card">
                    <!-- Video Thumbnail -->
                    <div class="relative">
                        <img src="<?php echo $thumbnail; ?>" alt="Video thumbnail" class="w-full h-64 object-cover">
                        <div class="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-50"></div>
                        <div class="absolute bottom-0 left-0 p-4">
                            <h3 class="text-xl font-bold text-white"><?php echo isset($videoInfo['title']) ? $videoInfo['title'] : 'YouTube Video'; ?></h3>
                        </div>
                    </div>

                    <!-- Download Options -->
                    <div class="p-6">
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">Available Download Formats</h3>
                        <div class="space-y-3">
                            <?php foreach ($formats as $format): ?>
                                <div class="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                                    <div>
                                        <span class="font-medium text-gray-800"><?php echo $format['quality'] ?: 'Standard Quality'; ?></span>
                                        <span class="text-sm text-gray-500 ml-2"><?php echo $format['type']; ?></span>
                                    </div>
                                    <a href="<?php echo $format['url']; ?>" 
                                       class="gradient-bg text-white px-4 py-2 rounded-lg download-btn text-sm font-medium"
                                       download>
                                        Download
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- How To Section -->
            <div class="bg-white rounded-xl shadow-md p-6 mt-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">How to Download YouTube Videos</h2>
                <ol class="list-decimal list-inside space-y-2 text-gray-700">
                    <li>Copy the URL of the YouTube video you want to download</li>
                    <li>Paste the URL in the input field above</li>
                    <li>Click "Get Download Links" button</li>
                    <li>Choose your preferred format and quality</li>
                    <li>Click "Download" to save the video to your device</li>
                </ol>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <!--<footer class="bg-gray-800 text-white py-8">-->
    <!--    <div class="container mx-auto px-4">-->
    <!--        <div class="text-center">-->
    <!--            <p>&copy; <?php echo date('Y'); ?> YouTube Video Downloader. All rights reserved.</p>-->
    <!--            <p class="text-gray-400 mt-2">This tool is for educational purposes only.</p>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</footer>-->
</body>

<?php include 'footer.php';?>

</html>