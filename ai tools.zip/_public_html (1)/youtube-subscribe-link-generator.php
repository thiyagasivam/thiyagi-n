<?php include 'header.php';?>

<?php
// Function to generate a YouTube subscribe link
function generateSubscribeLink($channelId) {
    return "https://www.youtube.com/channel/$channelId?sub_confirmation=1";
}

// Handle form submission
$subscribeLink = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $channelId = trim($_POST['channel_id']);
    if (!empty($channelId)) {
        $subscribeLink = generateSubscribeLink($channelId);
    } else {
        $error = 'Please enter a valid YouTube Channel ID.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Subscribe Link Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold text-center mb-6">YouTube Subscribe Link Generator</h1>
        <form method="POST" class="bg-white p-6 rounded-lg shadow-md">
            <div class="mb-4">
                <label for="channel_id" class="block text-gray-700 font-bold mb-2">Enter YouTube Channel ID:</label>
                <input type="text" name="channel_id" id="channel_id" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., UC1234567890ABCDEF" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300">Generate Subscribe Link</button>
        </form>
        <?php if (!empty($subscribeLink)): ?>
            <div class="mt-6 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-2xl font-bold text-gray-800">Generated Subscribe Link:</h2>
                <a href="<?php echo htmlspecialchars($subscribeLink); ?>" target="_blank" class="text-blue-500 text-xl mt-2 block break-all"><?php echo htmlspecialchars($subscribeLink); ?></a>
            </div>
        <?php elseif (!empty($error)): ?>
            <div class="mt-6 bg-red-100 p-6 rounded-lg shadow-md">
                <p class="text-red-700 text-xl"><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>
<?php include 'footer.php';?>

</html>